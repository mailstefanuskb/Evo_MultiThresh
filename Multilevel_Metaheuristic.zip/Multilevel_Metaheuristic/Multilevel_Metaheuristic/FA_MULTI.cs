﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Metaheuristic
{
    class FA_MULTI
    {
        private int level = new int();
        private List<double> posi = new List<double>();
        private double maxposs, minposs = new double();
        private double topLimit, btmLimit = new double();
        private double temp = new double();
        private Random random = new Random();

        private double random_by_seed = new double();
        private double seed_xk = new double();
        private double seed_a = new double();
        private double seed_k = new double();
        private double seed_M = new double();
        private Boolean isSeed = false;

        public FA_MULTI(int lv, double minpos, double maxpos, double tl, double bl, Boolean useSeed, int thisPos)
        {
            isSeed = useSeed;
            seed_a = 11;
            seed_k = 2;
            seed_M = 7919;

            if (isSeed)
            {
                seed_xk = Convert.ToDouble(Math.Pow(Convert.ToInt32(seed_a), Convert.ToInt32(seed_k)) % Convert.ToInt32(seed_M));
                for (int a = 0; a < thisPos; a++) reRandom(seed_xk, seed_a, seed_M);
            }

            level = lv;
            this.maxposs = maxpos;
            this.minposs = minpos;
            this.topLimit = tl;
            this.btmLimit = bl;
            for (int a = 0; a < level; a++)
            {
                posi.Add(random.NextDouble() * (maxposs - minposs) + minposs);
            }
            posi.Sort();
        }

        public double[] getPos()
        {
            return posi.ToArray();
        }

        public void setPos(double[] posit)
        {
            for (int a = 0; a < level; a++)
            {
                posi[a] = Convert.ToDouble(posit[a]);
            }
            posi.Sort();
        }

        public void changePos(FA_MULTI ind, double BETA, double ALPHA)
        {
            random = new Random();            
            for (int a = 0; a < level; a++)
            {
                temp = posi[a];                
                //random with seed?
                if (isSeed)
                {
                    random_by_seed = seed_xk / seed_M;
                    posi[a] = posi[a] + BETA * (ind.getPos()[a] - posi[a]) + ALPHA * (random_by_seed - 0.5);
                    reRandom(seed_xk, seed_a, seed_M);
                }
                else
                {
                    //random
                    posi[a] = posi[a] + BETA * (ind.getPos()[a] - posi[a]) + ALPHA * (random.NextDouble() - 0.5);
                }
                if (posi[a] > topLimit || posi[a] < btmLimit) posi[a] = temp;
            }
            //if (isSeed) reRandom(seed_xk, seed_a, seed_M);
            posi.Sort();
        }

        public void reRandom(double rseed_xk, double rseed_a, double rseed_M)
        {
            this.seed_xk = Convert.ToDouble((Convert.ToInt32(rseed_xk) * Convert.ToInt32(rseed_a)) % Convert.ToInt32(rseed_M));           
        }
    }
}
