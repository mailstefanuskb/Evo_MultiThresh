﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Metaheuristic
{
    class FA_5D
    {
        private List<double> posi = new List<double>();
        private double maxposs, minposs = new double();
        private double temp = new double();
        private Random random = new Random();

        public FA_5D(double minpos, double maxpos)
        {
            this.maxposs = maxpos;
            this.minposs = minpos;
            for (int a = 0; a < 5; a++)
            {
                posi.Add(random.NextDouble() * (maxposs - minposs) + minposs);
            }
        }

        public double[] getPos()
        {            
            return posi.ToArray();
        }

        public void changePos(FA_5D ind, double BETA, double ALPHA)
        {
            random = new Random();
            for (int a = 0; a < 5; a++)
            {
                temp = posi[a];
                posi[a] = posi[a] + BETA * (ind.getPos()[a] - posi[a]) + ALPHA * (random.NextDouble() - 0.5);
                if (posi[a] > maxposs || posi[a] < minposs) posi[a] = temp;
            }
        }
    }
}
