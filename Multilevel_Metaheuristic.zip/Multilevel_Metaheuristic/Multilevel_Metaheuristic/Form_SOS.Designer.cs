﻿namespace Multilevel_Metaheuristic
{
    partial class Form_SOS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rtbAlpha = new System.Windows.Forms.RichTextBox();
            this.textAlpha = new System.Windows.Forms.TextBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbMode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numAtasPosisi = new System.Windows.Forms.NumericUpDown();
            this.numBawahPosisi = new System.Windows.Forms.NumericUpDown();
            this.numIterations = new System.Windows.Forms.NumericUpDown();
            this.numPopulation = new System.Windows.Forms.NumericUpDown();
            this.cbFunction = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbPicture = new System.Windows.Forms.GroupBox();
            this.checkBoxColor = new System.Windows.Forms.CheckBox();
            this.btnLoadProcessedImage = new System.Windows.Forms.Button();
            this.chartGrayLevel = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lbOtsu = new System.Windows.Forms.Label();
            this.lbOriginal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.originalImage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.processedImage = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnLog = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.numLog = new System.Windows.Forms.NumericUpDown();
            this.rtbAll = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIterations)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPopulation)).BeginInit();
            this.gbPicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLog)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbAlpha);
            this.groupBox1.Controls.Add(this.textAlpha);
            this.groupBox1.Location = new System.Drawing.Point(272, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(279, 660);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Best Organism";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(187, 480);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 171);
            this.button1.TabIndex = 2;
            this.button1.Text = "Copy";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtbAlpha
            // 
            this.rtbAlpha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAlpha.Location = new System.Drawing.Point(9, 58);
            this.rtbAlpha.Margin = new System.Windows.Forms.Padding(4);
            this.rtbAlpha.Name = "rtbAlpha";
            this.rtbAlpha.ReadOnly = true;
            this.rtbAlpha.Size = new System.Drawing.Size(257, 580);
            this.rtbAlpha.TabIndex = 1;
            this.rtbAlpha.Text = "";
            // 
            // textAlpha
            // 
            this.textAlpha.Location = new System.Drawing.Point(9, 25);
            this.textAlpha.Margin = new System.Windows.Forms.Padding(4);
            this.textAlpha.Name = "textAlpha";
            this.textAlpha.ReadOnly = true;
            this.textAlpha.Size = new System.Drawing.Size(257, 22);
            this.textAlpha.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(13, 576);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(167, 75);
            this.btnRefresh.TabIndex = 11;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(13, 480);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(167, 75);
            this.btnStart.TabIndex = 10;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cbMode);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.numAtasPosisi);
            this.groupBox4.Controls.Add(this.numBawahPosisi);
            this.groupBox4.Controls.Add(this.numIterations);
            this.groupBox4.Controls.Add(this.numPopulation);
            this.groupBox4.Controls.Add(this.cbFunction);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(13, 13);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(251, 449);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Settings";
            // 
            // cbMode
            // 
            this.cbMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMode.Enabled = false;
            this.cbMode.FormattingEnabled = true;
            this.cbMode.Items.AddRange(new object[] {
            "Minimum",
            "Maximum"});
            this.cbMode.Location = new System.Drawing.Point(13, 126);
            this.cbMode.Margin = new System.Windows.Forms.Padding(4);
            this.cbMode.Name = "cbMode";
            this.cbMode.Size = new System.Drawing.Size(220, 24);
            this.cbMode.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 96);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Optimization";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 399);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Top";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 359);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Bottom";
            // 
            // numAtasPosisi
            // 
            this.numAtasPosisi.DecimalPlaces = 3;
            this.numAtasPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numAtasPosisi.Location = new System.Drawing.Point(75, 399);
            this.numAtasPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numAtasPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numAtasPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numAtasPosisi.Name = "numAtasPosisi";
            this.numAtasPosisi.Size = new System.Drawing.Size(160, 22);
            this.numAtasPosisi.TabIndex = 8;
            // 
            // numBawahPosisi
            // 
            this.numBawahPosisi.DecimalPlaces = 3;
            this.numBawahPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numBawahPosisi.Location = new System.Drawing.Point(75, 351);
            this.numBawahPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numBawahPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numBawahPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numBawahPosisi.Name = "numBawahPosisi";
            this.numBawahPosisi.Size = new System.Drawing.Size(160, 22);
            this.numBawahPosisi.TabIndex = 7;
            // 
            // numIterations
            // 
            this.numIterations.Location = new System.Drawing.Point(13, 268);
            this.numIterations.Margin = new System.Windows.Forms.Padding(4);
            this.numIterations.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numIterations.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numIterations.Name = "numIterations";
            this.numIterations.Size = new System.Drawing.Size(221, 22);
            this.numIterations.TabIndex = 6;
            this.numIterations.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numPopulation
            // 
            this.numPopulation.Location = new System.Drawing.Point(13, 192);
            this.numPopulation.Margin = new System.Windows.Forms.Padding(4);
            this.numPopulation.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numPopulation.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numPopulation.Name = "numPopulation";
            this.numPopulation.Size = new System.Drawing.Size(221, 22);
            this.numPopulation.TabIndex = 5;
            this.numPopulation.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // cbFunction
            // 
            this.cbFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFunction.FormattingEnabled = true;
            this.cbFunction.Items.AddRange(new object[] {
            "Michaelwicz5 (Test Function)",
            "Otsu - m = 2",
            "Otsu - m = 3",
            "Otsu - m = 4",
            "Otsu - m = 5"});
            this.cbFunction.Location = new System.Drawing.Point(13, 59);
            this.cbFunction.Margin = new System.Windows.Forms.Padding(4);
            this.cbFunction.Name = "cbFunction";
            this.cbFunction.Size = new System.Drawing.Size(220, 24);
            this.cbFunction.TabIndex = 4;
            this.cbFunction.SelectedIndexChanged += new System.EventHandler(this.cbFunction_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 320);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Range Posisi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 235);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Max Iterations";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 162);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Population";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Function";
            // 
            // gbPicture
            // 
            this.gbPicture.Controls.Add(this.checkBoxColor);
            this.gbPicture.Controls.Add(this.btnLoadProcessedImage);
            this.gbPicture.Controls.Add(this.chartGrayLevel);
            this.gbPicture.Controls.Add(this.btnLoadImage);
            this.gbPicture.Controls.Add(this.label17);
            this.gbPicture.Controls.Add(this.lbOtsu);
            this.gbPicture.Controls.Add(this.lbOriginal);
            this.gbPicture.Controls.Add(this.panel1);
            this.gbPicture.Controls.Add(this.panel2);
            this.gbPicture.Location = new System.Drawing.Point(972, 13);
            this.gbPicture.Name = "gbPicture";
            this.gbPicture.Size = new System.Drawing.Size(562, 660);
            this.gbPicture.TabIndex = 18;
            this.gbPicture.TabStop = false;
            this.gbPicture.Text = "Image";
            // 
            // checkBoxColor
            // 
            this.checkBoxColor.AutoSize = true;
            this.checkBoxColor.Location = new System.Drawing.Point(281, 320);
            this.checkBoxColor.Name = "checkBoxColor";
            this.checkBoxColor.Size = new System.Drawing.Size(149, 21);
            this.checkBoxColor.TabIndex = 10;
            this.checkBoxColor.Text = "Color Per Segment";
            this.checkBoxColor.UseVisualStyleBackColor = true;
            // 
            // btnLoadProcessedImage
            // 
            this.btnLoadProcessedImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProcessedImage.Location = new System.Drawing.Point(431, 29);
            this.btnLoadProcessedImage.Name = "btnLoadProcessedImage";
            this.btnLoadProcessedImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadProcessedImage.TabIndex = 9;
            this.btnLoadProcessedImage.Text = "Load Image";
            this.btnLoadProcessedImage.UseVisualStyleBackColor = true;
            this.btnLoadProcessedImage.Click += new System.EventHandler(this.btnLoadProcessedImage_Click);
            // 
            // chartGrayLevel
            // 
            chartArea1.Name = "ChartArea1";
            this.chartGrayLevel.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartGrayLevel.Legends.Add(legend1);
            this.chartGrayLevel.Location = new System.Drawing.Point(25, 381);
            this.chartGrayLevel.Name = "chartGrayLevel";
            this.chartGrayLevel.Size = new System.Drawing.Size(512, 257);
            this.chartGrayLevel.TabIndex = 6;
            this.chartGrayLevel.Text = "chart1";
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadImage.Location = new System.Drawing.Point(169, 29);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadImage.TabIndex = 5;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Gray Level Graph";
            // 
            // lbOtsu
            // 
            this.lbOtsu.AutoSize = true;
            this.lbOtsu.Location = new System.Drawing.Point(278, 35);
            this.lbOtsu.Name = "lbOtsu";
            this.lbOtsu.Size = new System.Drawing.Size(0, 17);
            this.lbOtsu.TabIndex = 3;
            // 
            // lbOriginal
            // 
            this.lbOriginal.AutoSize = true;
            this.lbOriginal.Location = new System.Drawing.Point(19, 35);
            this.lbOriginal.Name = "lbOriginal";
            this.lbOriginal.Size = new System.Drawing.Size(99, 17);
            this.lbOriginal.TabIndex = 2;
            this.lbOriginal.Text = "Original Image";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.originalImage);
            this.panel1.Location = new System.Drawing.Point(19, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 256);
            this.panel1.TabIndex = 7;
            // 
            // originalImage
            // 
            this.originalImage.BackColor = System.Drawing.SystemColors.Window;
            this.originalImage.Location = new System.Drawing.Point(0, 0);
            this.originalImage.Name = "originalImage";
            this.originalImage.Size = new System.Drawing.Size(256, 256);
            this.originalImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.originalImage.TabIndex = 0;
            this.originalImage.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.processedImage);
            this.panel2.Location = new System.Drawing.Point(281, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 256);
            this.panel2.TabIndex = 8;
            // 
            // processedImage
            // 
            this.processedImage.BackColor = System.Drawing.SystemColors.Window;
            this.processedImage.Location = new System.Drawing.Point(0, 0);
            this.processedImage.Name = "processedImage";
            this.processedImage.Size = new System.Drawing.Size(256, 256);
            this.processedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.processedImage.TabIndex = 1;
            this.processedImage.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnLog);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.numLog);
            this.groupBox3.Controls.Add(this.rtbAll);
            this.groupBox3.Location = new System.Drawing.Point(559, 13);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(376, 660);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Log Organisms";
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(278, 29);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(75, 23);
            this.btnLog.TabIndex = 4;
            this.btnLog.Text = "OK";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(27, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 17);
            this.label21.TabIndex = 3;
            this.label21.Text = "Iteration No.";
            // 
            // numLog
            // 
            this.numLog.Increment = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numLog.Location = new System.Drawing.Point(118, 29);
            this.numLog.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numLog.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLog.Name = "numLog";
            this.numLog.Size = new System.Drawing.Size(153, 22);
            this.numLog.TabIndex = 2;
            this.numLog.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLog.ValueChanged += new System.EventHandler(this.numLog_ValueChanged);
            // 
            // rtbAll
            // 
            this.rtbAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAll.Location = new System.Drawing.Point(27, 58);
            this.rtbAll.Margin = new System.Windows.Forms.Padding(4);
            this.rtbAll.Name = "rtbAll";
            this.rtbAll.ReadOnly = true;
            this.rtbAll.Size = new System.Drawing.Size(326, 594);
            this.rtbAll.TabIndex = 1;
            this.rtbAll.Text = "";
            // 
            // Form_SOS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1557, 686);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbPicture);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.groupBox4);
            this.Name = "Form_SOS";
            this.Text = "Form_SOS";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIterations)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPopulation)).EndInit();
            this.gbPicture.ResumeLayout(false);
            this.gbPicture.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLog)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtbAlpha;
        private System.Windows.Forms.TextBox textAlpha;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cbMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numAtasPosisi;
        private System.Windows.Forms.NumericUpDown numBawahPosisi;
        private System.Windows.Forms.NumericUpDown numIterations;
        private System.Windows.Forms.NumericUpDown numPopulation;
        private System.Windows.Forms.ComboBox cbFunction;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbPicture;
        private System.Windows.Forms.CheckBox checkBoxColor;
        private System.Windows.Forms.Button btnLoadProcessedImage;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGrayLevel;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbOtsu;
        private System.Windows.Forms.Label lbOriginal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox originalImage;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox processedImage;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numLog;
        private System.Windows.Forms.RichTextBox rtbAll;
        private System.Windows.Forms.Button button1;
    }
}