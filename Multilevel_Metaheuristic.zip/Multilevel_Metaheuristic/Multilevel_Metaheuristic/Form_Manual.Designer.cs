﻿namespace Multilevel_Metaheuristic
{
    partial class Form_Manual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.gbPicture = new System.Windows.Forms.GroupBox();
            this.checkBoxColor = new System.Windows.Forms.CheckBox();
            this.btnLoadProcessedImage = new System.Windows.Forms.Button();
            this.chartGrayLevel = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lbOtsu = new System.Windows.Forms.Label();
            this.lbOriginal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.originalImage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.processedImage = new System.Windows.Forms.PictureBox();
            this.cbFunction = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.num_1 = new System.Windows.Forms.NumericUpDown();
            this.num_2 = new System.Windows.Forms.NumericUpDown();
            this.num_3 = new System.Windows.Forms.NumericUpDown();
            this.num_4 = new System.Windows.Forms.NumericUpDown();
            this.num_5 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numAtasPosisi = new System.Windows.Forms.NumericUpDown();
            this.numBawahPosisi = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_ok = new System.Windows.Forms.Button();
            this.btn_clr = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.gbPicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).BeginInit();
            this.SuspendLayout();
            // 
            // gbPicture
            // 
            this.gbPicture.Controls.Add(this.checkBoxColor);
            this.gbPicture.Controls.Add(this.btnLoadProcessedImage);
            this.gbPicture.Controls.Add(this.chartGrayLevel);
            this.gbPicture.Controls.Add(this.btnLoadImage);
            this.gbPicture.Controls.Add(this.label17);
            this.gbPicture.Controls.Add(this.lbOtsu);
            this.gbPicture.Controls.Add(this.lbOriginal);
            this.gbPicture.Controls.Add(this.panel1);
            this.gbPicture.Controls.Add(this.panel2);
            this.gbPicture.Location = new System.Drawing.Point(410, 12);
            this.gbPicture.Name = "gbPicture";
            this.gbPicture.Size = new System.Drawing.Size(562, 660);
            this.gbPicture.TabIndex = 18;
            this.gbPicture.TabStop = false;
            this.gbPicture.Text = "Image";
            // 
            // checkBoxColor
            // 
            this.checkBoxColor.AutoSize = true;
            this.checkBoxColor.Location = new System.Drawing.Point(281, 320);
            this.checkBoxColor.Name = "checkBoxColor";
            this.checkBoxColor.Size = new System.Drawing.Size(149, 21);
            this.checkBoxColor.TabIndex = 10;
            this.checkBoxColor.Text = "Color Per Segment";
            this.checkBoxColor.UseVisualStyleBackColor = true;
            // 
            // btnLoadProcessedImage
            // 
            this.btnLoadProcessedImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProcessedImage.Location = new System.Drawing.Point(431, 29);
            this.btnLoadProcessedImage.Name = "btnLoadProcessedImage";
            this.btnLoadProcessedImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadProcessedImage.TabIndex = 9;
            this.btnLoadProcessedImage.Text = "Load Image";
            this.btnLoadProcessedImage.UseVisualStyleBackColor = true;
            this.btnLoadProcessedImage.Click += new System.EventHandler(this.btnLoadProcessedImage_Click);
            // 
            // chartGrayLevel
            // 
            chartArea1.Name = "ChartArea1";
            this.chartGrayLevel.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartGrayLevel.Legends.Add(legend1);
            this.chartGrayLevel.Location = new System.Drawing.Point(25, 381);
            this.chartGrayLevel.Name = "chartGrayLevel";
            this.chartGrayLevel.Size = new System.Drawing.Size(512, 257);
            this.chartGrayLevel.TabIndex = 6;
            this.chartGrayLevel.Text = "chart1";
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadImage.Location = new System.Drawing.Point(169, 29);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadImage.TabIndex = 5;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Gray Level Graph";
            // 
            // lbOtsu
            // 
            this.lbOtsu.AutoSize = true;
            this.lbOtsu.Location = new System.Drawing.Point(278, 35);
            this.lbOtsu.Name = "lbOtsu";
            this.lbOtsu.Size = new System.Drawing.Size(0, 17);
            this.lbOtsu.TabIndex = 3;
            // 
            // lbOriginal
            // 
            this.lbOriginal.AutoSize = true;
            this.lbOriginal.Location = new System.Drawing.Point(19, 35);
            this.lbOriginal.Name = "lbOriginal";
            this.lbOriginal.Size = new System.Drawing.Size(99, 17);
            this.lbOriginal.TabIndex = 2;
            this.lbOriginal.Text = "Original Image";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.originalImage);
            this.panel1.Location = new System.Drawing.Point(19, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 256);
            this.panel1.TabIndex = 7;
            // 
            // originalImage
            // 
            this.originalImage.BackColor = System.Drawing.SystemColors.Window;
            this.originalImage.Location = new System.Drawing.Point(0, 0);
            this.originalImage.Name = "originalImage";
            this.originalImage.Size = new System.Drawing.Size(256, 256);
            this.originalImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.originalImage.TabIndex = 0;
            this.originalImage.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.processedImage);
            this.panel2.Location = new System.Drawing.Point(281, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 256);
            this.panel2.TabIndex = 8;
            // 
            // processedImage
            // 
            this.processedImage.BackColor = System.Drawing.SystemColors.Window;
            this.processedImage.Location = new System.Drawing.Point(0, 0);
            this.processedImage.Name = "processedImage";
            this.processedImage.Size = new System.Drawing.Size(256, 256);
            this.processedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.processedImage.TabIndex = 1;
            this.processedImage.TabStop = false;
            // 
            // cbFunction
            // 
            this.cbFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFunction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbFunction.FormattingEnabled = true;
            this.cbFunction.Items.AddRange(new object[] {
            "Pilihan",
            "Otsu - m = 2",
            "Otsu - m = 3",
            "Otsu - m = 4",
            "Otsu - m = 5"});
            this.cbFunction.Location = new System.Drawing.Point(17, 55);
            this.cbFunction.Margin = new System.Windows.Forms.Padding(4);
            this.cbFunction.Name = "cbFunction";
            this.cbFunction.Size = new System.Drawing.Size(222, 33);
            this.cbFunction.TabIndex = 20;
            this.cbFunction.SelectedIndexChanged += new System.EventHandler(this.cbFunction_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 25);
            this.label1.TabIndex = 19;
            this.label1.Text = "Function";
            // 
            // num_1
            // 
            this.num_1.DecimalPlaces = 3;
            this.num_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_1.Location = new System.Drawing.Point(16, 132);
            this.num_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.num_1.Name = "num_1";
            this.num_1.Size = new System.Drawing.Size(271, 30);
            this.num_1.TabIndex = 21;
            // 
            // num_2
            // 
            this.num_2.DecimalPlaces = 3;
            this.num_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_2.Location = new System.Drawing.Point(17, 218);
            this.num_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.num_2.Name = "num_2";
            this.num_2.Size = new System.Drawing.Size(271, 30);
            this.num_2.TabIndex = 22;
            // 
            // num_3
            // 
            this.num_3.DecimalPlaces = 3;
            this.num_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_3.Location = new System.Drawing.Point(17, 300);
            this.num_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.num_3.Name = "num_3";
            this.num_3.Size = new System.Drawing.Size(271, 30);
            this.num_3.TabIndex = 23;
            // 
            // num_4
            // 
            this.num_4.DecimalPlaces = 3;
            this.num_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_4.Location = new System.Drawing.Point(17, 382);
            this.num_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.num_4.Name = "num_4";
            this.num_4.Size = new System.Drawing.Size(271, 30);
            this.num_4.TabIndex = 24;
            // 
            // num_5
            // 
            this.num_5.DecimalPlaces = 3;
            this.num_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_5.Location = new System.Drawing.Point(17, 469);
            this.num_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.num_5.Name = "num_5";
            this.num_5.Size = new System.Drawing.Size(271, 30);
            this.num_5.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 104);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 25);
            this.label2.TabIndex = 26;
            this.label2.Text = "Threshold #1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 190);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "Threshold #2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 272);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 25);
            this.label4.TabIndex = 28;
            this.label4.Text = "Threshold #3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 351);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 25);
            this.label5.TabIndex = 29;
            this.label5.Text = "Threshold #4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 441);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 25);
            this.label6.TabIndex = 30;
            this.label6.Text = "Threshold #5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 610);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 25);
            this.label7.TabIndex = 35;
            this.label7.Text = "Top";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 570);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 25);
            this.label8.TabIndex = 34;
            this.label8.Text = "Bottom";
            // 
            // numAtasPosisi
            // 
            this.numAtasPosisi.DecimalPlaces = 3;
            this.numAtasPosisi.Enabled = false;
            this.numAtasPosisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numAtasPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numAtasPosisi.Location = new System.Drawing.Point(129, 613);
            this.numAtasPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numAtasPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numAtasPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numAtasPosisi.Name = "numAtasPosisi";
            this.numAtasPosisi.ReadOnly = true;
            this.numAtasPosisi.Size = new System.Drawing.Size(207, 30);
            this.numAtasPosisi.TabIndex = 33;
            // 
            // numBawahPosisi
            // 
            this.numBawahPosisi.DecimalPlaces = 3;
            this.numBawahPosisi.Enabled = false;
            this.numBawahPosisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numBawahPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numBawahPosisi.Location = new System.Drawing.Point(129, 565);
            this.numBawahPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numBawahPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numBawahPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numBawahPosisi.Name = "numBawahPosisi";
            this.numBawahPosisi.ReadOnly = true;
            this.numBawahPosisi.Size = new System.Drawing.Size(206, 30);
            this.numBawahPosisi.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 531);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 25);
            this.label9.TabIndex = 31;
            this.label9.Text = "Range Posisi";
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(246, 55);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(60, 33);
            this.btn_ok.TabIndex = 36;
            this.btn_ok.Text = "LOCK";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // btn_clr
            // 
            this.btn_clr.Enabled = false;
            this.btn_clr.Location = new System.Drawing.Point(312, 55);
            this.btn_clr.Name = "btn_clr";
            this.btn_clr.Size = new System.Drawing.Size(80, 33);
            this.btn_clr.TabIndex = 37;
            this.btn_clr.Text = "UNLOCK";
            this.btn_clr.UseVisualStyleBackColor = true;
            this.btn_clr.Click += new System.EventHandler(this.btn_clr_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(107, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 25);
            this.label10.TabIndex = 12;
            this.label10.Text = "Score: -";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(990, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(279, 638);
            this.richTextBox1.TabIndex = 38;
            this.richTextBox1.Text = "";
            // 
            // Form_Manual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1281, 666);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btn_clr);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.numAtasPosisi);
            this.Controls.Add(this.numBawahPosisi);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.num_5);
            this.Controls.Add(this.num_4);
            this.Controls.Add(this.num_3);
            this.Controls.Add(this.num_2);
            this.Controls.Add(this.num_1);
            this.Controls.Add(this.cbFunction);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbPicture);
            this.Name = "Form_Manual";
            this.Text = "Form_Manual";
            this.Load += new System.EventHandler(this.Form_Manual_Load);
            this.gbPicture.ResumeLayout(false);
            this.gbPicture.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPicture;
        private System.Windows.Forms.CheckBox checkBoxColor;
        private System.Windows.Forms.Button btnLoadProcessedImage;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGrayLevel;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbOtsu;
        private System.Windows.Forms.Label lbOriginal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox originalImage;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox processedImage;
        private System.Windows.Forms.ComboBox cbFunction;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown num_1;
        private System.Windows.Forms.NumericUpDown num_2;
        private System.Windows.Forms.NumericUpDown num_3;
        private System.Windows.Forms.NumericUpDown num_4;
        private System.Windows.Forms.NumericUpDown num_5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numAtasPosisi;
        private System.Windows.Forms.NumericUpDown numBawahPosisi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Button btn_clr;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}