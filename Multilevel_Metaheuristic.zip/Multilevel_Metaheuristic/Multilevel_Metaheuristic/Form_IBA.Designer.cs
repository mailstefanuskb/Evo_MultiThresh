﻿namespace Multilevel_Metaheuristic
{
    partial class Form_IBA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.cbFunction = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rtbBest = new System.Windows.Forms.RichTextBox();
            this.textBest = new System.Windows.Forms.TextBox();
            this.numIterations = new System.Windows.Forms.NumericUpDown();
            this.cbMode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numAtasPosisi = new System.Windows.Forms.NumericUpDown();
            this.numBawahPosisi = new System.Windows.Forms.NumericUpDown();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numScalingFactor = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.numC = new System.Windows.Forms.NumericUpDown();
            this.numF = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.numBeta = new System.Windows.Forms.NumericUpDown();
            this.numAlpha = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.num_initpulse = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.num_Amin = new System.Windows.Forms.NumericUpDown();
            this.num_Ainit = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.num_fmax = new System.Windows.Forms.NumericUpDown();
            this.num_fmin = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numPopulation = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.gbPicture = new System.Windows.Forms.GroupBox();
            this.checkBoxColor = new System.Windows.Forms.CheckBox();
            this.btnLoadProcessedImage = new System.Windows.Forms.Button();
            this.chartGrayLevel = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lbOtsu = new System.Windows.Forms.Label();
            this.lbOriginal = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.originalImage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.processedImage = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnLog = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.numLog = new System.Windows.Forms.NumericUpDown();
            this.rtbAll = new System.Windows.Forms.RichTextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIterations)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numScalingFactor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAlpha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_initpulse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Amin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ainit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_fmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_fmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPopulation)).BeginInit();
            this.gbPicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLog)).BeginInit();
            this.SuspendLayout();
            // 
            // cbFunction
            // 
            this.cbFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFunction.FormattingEnabled = true;
            this.cbFunction.Items.AddRange(new object[] {
            "Michaelwicz5 (Test Function)",
            "Otsu - m = 2",
            "Otsu - m = 3",
            "Otsu - m = 4",
            "Otsu - m = 5"});
            this.cbFunction.Location = new System.Drawing.Point(13, 59);
            this.cbFunction.Margin = new System.Windows.Forms.Padding(4);
            this.cbFunction.Name = "cbFunction";
            this.cbFunction.Size = new System.Drawing.Size(222, 24);
            this.cbFunction.TabIndex = 4;
            this.cbFunction.SelectedIndexChanged += new System.EventHandler(this.cbFunction_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 320);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Range Posisi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 235);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Max Iterations";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Function";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(13, 594);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(310, 89);
            this.btnRefresh.TabIndex = 15;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(13, 497);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(310, 89);
            this.btnStart.TabIndex = 14;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbBest);
            this.groupBox1.Controls.Add(this.textBest);
            this.groupBox1.Location = new System.Drawing.Point(487, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(271, 660);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Best Bat";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(330, 497);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 186);
            this.button1.TabIndex = 2;
            this.button1.Text = "Copy";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rtbBest
            // 
            this.rtbBest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbBest.Location = new System.Drawing.Point(9, 58);
            this.rtbBest.Margin = new System.Windows.Forms.Padding(4);
            this.rtbBest.Name = "rtbBest";
            this.rtbBest.ReadOnly = true;
            this.rtbBest.Size = new System.Drawing.Size(254, 594);
            this.rtbBest.TabIndex = 1;
            this.rtbBest.Text = "";
            // 
            // textBest
            // 
            this.textBest.Location = new System.Drawing.Point(9, 25);
            this.textBest.Margin = new System.Windows.Forms.Padding(4);
            this.textBest.Name = "textBest";
            this.textBest.ReadOnly = true;
            this.textBest.Size = new System.Drawing.Size(254, 22);
            this.textBest.TabIndex = 0;
            // 
            // numIterations
            // 
            this.numIterations.Location = new System.Drawing.Point(13, 268);
            this.numIterations.Margin = new System.Windows.Forms.Padding(4);
            this.numIterations.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numIterations.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numIterations.Name = "numIterations";
            this.numIterations.Size = new System.Drawing.Size(221, 22);
            this.numIterations.TabIndex = 6;
            this.numIterations.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // cbMode
            // 
            this.cbMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMode.Enabled = false;
            this.cbMode.FormattingEnabled = true;
            this.cbMode.Items.AddRange(new object[] {
            "Minimum",
            "Maximum"});
            this.cbMode.Location = new System.Drawing.Point(13, 126);
            this.cbMode.Margin = new System.Windows.Forms.Padding(4);
            this.cbMode.Name = "cbMode";
            this.cbMode.Size = new System.Drawing.Size(222, 24);
            this.cbMode.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 96);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Optimization";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 399);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Top";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 359);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Bottom";
            // 
            // numAtasPosisi
            // 
            this.numAtasPosisi.DecimalPlaces = 3;
            this.numAtasPosisi.Enabled = false;
            this.numAtasPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numAtasPosisi.Location = new System.Drawing.Point(75, 399);
            this.numAtasPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numAtasPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numAtasPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numAtasPosisi.Name = "numAtasPosisi";
            this.numAtasPosisi.Size = new System.Drawing.Size(160, 22);
            this.numAtasPosisi.TabIndex = 8;
            // 
            // numBawahPosisi
            // 
            this.numBawahPosisi.DecimalPlaces = 3;
            this.numBawahPosisi.Enabled = false;
            this.numBawahPosisi.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numBawahPosisi.Location = new System.Drawing.Point(75, 351);
            this.numBawahPosisi.Margin = new System.Windows.Forms.Padding(4);
            this.numBawahPosisi.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numBawahPosisi.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numBawahPosisi.Name = "numBawahPosisi";
            this.numBawahPosisi.Size = new System.Drawing.Size(160, 22);
            this.numBawahPosisi.TabIndex = 7;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Controls.Add(this.numPopulation);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.cbMode);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.numAtasPosisi);
            this.groupBox4.Controls.Add(this.numBawahPosisi);
            this.groupBox4.Controls.Add(this.numIterations);
            this.groupBox4.Controls.Add(this.cbFunction);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(13, 13);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(466, 454);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Settings";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numScalingFactor);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.numC);
            this.groupBox2.Controls.Add(this.numF);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.numBeta);
            this.groupBox2.Controls.Add(this.numAlpha);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.num_initpulse);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.num_Amin);
            this.groupBox2.Controls.Add(this.num_Ainit);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.num_fmax);
            this.groupBox2.Controls.Add(this.num_fmin);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(254, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 424);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parameters";
            // 
            // numScalingFactor
            // 
            this.numScalingFactor.DecimalPlaces = 8;
            this.numScalingFactor.Increment = new decimal(new int[] {
            1,
            0,
            0,
            524288});
            this.numScalingFactor.Location = new System.Drawing.Point(12, 395);
            this.numScalingFactor.Margin = new System.Windows.Forms.Padding(4);
            this.numScalingFactor.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numScalingFactor.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numScalingFactor.Name = "numScalingFactor";
            this.numScalingFactor.Size = new System.Drawing.Size(172, 22);
            this.numScalingFactor.TabIndex = 35;
            this.numScalingFactor.Value = new decimal(new int[] {
            1,
            0,
            0,
            524288});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 373);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 17);
            this.label20.TabIndex = 34;
            this.label20.Text = "Scaling Factor";
            // 
            // numC
            // 
            this.numC.DecimalPlaces = 3;
            this.numC.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numC.Location = new System.Drawing.Point(59, 341);
            this.numC.Margin = new System.Windows.Forms.Padding(4);
            this.numC.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numC.Name = "numC";
            this.numC.Size = new System.Drawing.Size(125, 22);
            this.numC.TabIndex = 33;
            this.numC.Value = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            // 
            // numF
            // 
            this.numF.DecimalPlaces = 3;
            this.numF.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numF.Location = new System.Drawing.Point(59, 314);
            this.numF.Margin = new System.Windows.Forms.Padding(4);
            this.numF.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numF.Name = "numF";
            this.numF.Size = new System.Drawing.Size(125, 22);
            this.numF.TabIndex = 32;
            this.numF.Value = new decimal(new int[] {
            75,
            0,
            0,
            131072});
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 343);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(17, 17);
            this.label18.TabIndex = 31;
            this.label18.Text = "C";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 316);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 17);
            this.label19.TabIndex = 30;
            this.label19.Text = "F";
            // 
            // numBeta
            // 
            this.numBeta.DecimalPlaces = 3;
            this.numBeta.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numBeta.Location = new System.Drawing.Point(59, 285);
            this.numBeta.Margin = new System.Windows.Forms.Padding(4);
            this.numBeta.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numBeta.Name = "numBeta";
            this.numBeta.Size = new System.Drawing.Size(125, 22);
            this.numBeta.TabIndex = 29;
            this.numBeta.Value = new decimal(new int[] {
            9,
            0,
            0,
            65536});
            // 
            // numAlpha
            // 
            this.numAlpha.DecimalPlaces = 3;
            this.numAlpha.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numAlpha.Location = new System.Drawing.Point(59, 257);
            this.numAlpha.Margin = new System.Windows.Forms.Padding(4);
            this.numAlpha.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAlpha.Name = "numAlpha";
            this.numAlpha.Size = new System.Drawing.Size(125, 22);
            this.numAlpha.TabIndex = 28;
            this.numAlpha.Value = new decimal(new int[] {
            995,
            0,
            0,
            196608});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 287);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 17);
            this.label16.TabIndex = 27;
            this.label16.Text = "Beta";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 259);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 17);
            this.label15.TabIndex = 26;
            this.label15.Text = "Alpha";
            // 
            // num_initpulse
            // 
            this.num_initpulse.DecimalPlaces = 3;
            this.num_initpulse.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.num_initpulse.Location = new System.Drawing.Point(12, 227);
            this.num_initpulse.Margin = new System.Windows.Forms.Padding(4);
            this.num_initpulse.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_initpulse.Name = "num_initpulse";
            this.num_initpulse.Size = new System.Drawing.Size(172, 22);
            this.num_initpulse.TabIndex = 25;
            this.num_initpulse.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 202);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 17);
            this.label14.TabIndex = 24;
            this.label14.Text = "Initial Pulse Rate";
            // 
            // num_Amin
            // 
            this.num_Amin.DecimalPlaces = 3;
            this.num_Amin.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.num_Amin.Location = new System.Drawing.Point(50, 169);
            this.num_Amin.Margin = new System.Windows.Forms.Padding(4);
            this.num_Amin.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_Amin.Name = "num_Amin";
            this.num_Amin.Size = new System.Drawing.Size(134, 22);
            this.num_Amin.TabIndex = 23;
            this.num_Amin.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.num_Amin.ValueChanged += new System.EventHandler(this.num_Amin_ValueChanged);
            // 
            // num_Ainit
            // 
            this.num_Ainit.DecimalPlaces = 3;
            this.num_Ainit.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.num_Ainit.Location = new System.Drawing.Point(50, 140);
            this.num_Ainit.Margin = new System.Windows.Forms.Padding(4);
            this.num_Ainit.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_Ainit.Name = "num_Ainit";
            this.num_Ainit.Size = new System.Drawing.Size(134, 22);
            this.num_Ainit.TabIndex = 22;
            this.num_Ainit.Value = new decimal(new int[] {
            95,
            0,
            0,
            131072});
            this.num_Ainit.ValueChanged += new System.EventHandler(this.num_Ainit_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 172);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 17);
            this.label11.TabIndex = 21;
            this.label11.Text = "Amin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 17);
            this.label12.TabIndex = 20;
            this.label12.Text = "Ainit";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 113);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 17);
            this.label13.TabIndex = 19;
            this.label13.Text = "Loudness";
            // 
            // num_fmax
            // 
            this.num_fmax.DecimalPlaces = 3;
            this.num_fmax.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.num_fmax.Location = new System.Drawing.Point(50, 81);
            this.num_fmax.Margin = new System.Windows.Forms.Padding(4);
            this.num_fmax.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.num_fmax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_fmax.Name = "num_fmax";
            this.num_fmax.Size = new System.Drawing.Size(134, 22);
            this.num_fmax.TabIndex = 18;
            this.num_fmax.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // num_fmin
            // 
            this.num_fmin.DecimalPlaces = 3;
            this.num_fmin.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.num_fmin.Location = new System.Drawing.Point(50, 52);
            this.num_fmin.Margin = new System.Windows.Forms.Padding(4);
            this.num_fmin.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.num_fmin.Name = "num_fmin";
            this.num_fmin.Size = new System.Drawing.Size(134, 22);
            this.num_fmin.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "fmax";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 17);
            this.label9.TabIndex = 1;
            this.label9.Text = "fmin";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Frequency";
            // 
            // numPopulation
            // 
            this.numPopulation.Location = new System.Drawing.Point(13, 201);
            this.numPopulation.Margin = new System.Windows.Forms.Padding(4);
            this.numPopulation.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numPopulation.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numPopulation.Name = "numPopulation";
            this.numPopulation.Size = new System.Drawing.Size(221, 22);
            this.numPopulation.TabIndex = 15;
            this.numPopulation.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 173);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Population";
            // 
            // gbPicture
            // 
            this.gbPicture.Controls.Add(this.checkBoxColor);
            this.gbPicture.Controls.Add(this.btnLoadProcessedImage);
            this.gbPicture.Controls.Add(this.chartGrayLevel);
            this.gbPicture.Controls.Add(this.btnLoadImage);
            this.gbPicture.Controls.Add(this.label17);
            this.gbPicture.Controls.Add(this.lbOtsu);
            this.gbPicture.Controls.Add(this.lbOriginal);
            this.gbPicture.Controls.Add(this.panel1);
            this.gbPicture.Controls.Add(this.panel2);
            this.gbPicture.Location = new System.Drawing.Point(1197, 14);
            this.gbPicture.Name = "gbPicture";
            this.gbPicture.Size = new System.Drawing.Size(562, 660);
            this.gbPicture.TabIndex = 17;
            this.gbPicture.TabStop = false;
            this.gbPicture.Text = "Image";
            // 
            // checkBoxColor
            // 
            this.checkBoxColor.AutoSize = true;
            this.checkBoxColor.Location = new System.Drawing.Point(281, 320);
            this.checkBoxColor.Name = "checkBoxColor";
            this.checkBoxColor.Size = new System.Drawing.Size(149, 21);
            this.checkBoxColor.TabIndex = 10;
            this.checkBoxColor.Text = "Color Per Segment";
            this.checkBoxColor.UseVisualStyleBackColor = true;
            // 
            // btnLoadProcessedImage
            // 
            this.btnLoadProcessedImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProcessedImage.Location = new System.Drawing.Point(431, 29);
            this.btnLoadProcessedImage.Name = "btnLoadProcessedImage";
            this.btnLoadProcessedImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadProcessedImage.TabIndex = 9;
            this.btnLoadProcessedImage.Text = "Load Image";
            this.btnLoadProcessedImage.UseVisualStyleBackColor = true;
            this.btnLoadProcessedImage.Click += new System.EventHandler(this.btnLoadProcessedImage_Click);
            // 
            // chartGrayLevel
            // 
            chartArea1.Name = "ChartArea1";
            this.chartGrayLevel.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartGrayLevel.Legends.Add(legend1);
            this.chartGrayLevel.Location = new System.Drawing.Point(25, 381);
            this.chartGrayLevel.Name = "chartGrayLevel";
            this.chartGrayLevel.Size = new System.Drawing.Size(512, 257);
            this.chartGrayLevel.TabIndex = 6;
            this.chartGrayLevel.Text = "chart1";
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadImage.Location = new System.Drawing.Point(169, 29);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(106, 23);
            this.btnLoadImage.TabIndex = 5;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 347);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Gray Level Graph";
            // 
            // lbOtsu
            // 
            this.lbOtsu.AutoSize = true;
            this.lbOtsu.Location = new System.Drawing.Point(278, 35);
            this.lbOtsu.Name = "lbOtsu";
            this.lbOtsu.Size = new System.Drawing.Size(0, 17);
            this.lbOtsu.TabIndex = 3;
            // 
            // lbOriginal
            // 
            this.lbOriginal.AutoSize = true;
            this.lbOriginal.Location = new System.Drawing.Point(19, 35);
            this.lbOriginal.Name = "lbOriginal";
            this.lbOriginal.Size = new System.Drawing.Size(99, 17);
            this.lbOriginal.TabIndex = 2;
            this.lbOriginal.Text = "Original Image";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.originalImage);
            this.panel1.Location = new System.Drawing.Point(19, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 256);
            this.panel1.TabIndex = 7;
            // 
            // originalImage
            // 
            this.originalImage.BackColor = System.Drawing.SystemColors.Window;
            this.originalImage.Location = new System.Drawing.Point(0, 0);
            this.originalImage.Name = "originalImage";
            this.originalImage.Size = new System.Drawing.Size(256, 256);
            this.originalImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.originalImage.TabIndex = 0;
            this.originalImage.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.processedImage);
            this.panel2.Location = new System.Drawing.Point(281, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 256);
            this.panel2.TabIndex = 8;
            // 
            // processedImage
            // 
            this.processedImage.BackColor = System.Drawing.SystemColors.Window;
            this.processedImage.Location = new System.Drawing.Point(0, 0);
            this.processedImage.Name = "processedImage";
            this.processedImage.Size = new System.Drawing.Size(256, 256);
            this.processedImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.processedImage.TabIndex = 1;
            this.processedImage.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnLog);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.numLog);
            this.groupBox3.Controls.Add(this.rtbAll);
            this.groupBox3.Location = new System.Drawing.Point(766, 14);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(395, 660);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Log Bats";
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(278, 29);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(99, 23);
            this.btnLog.TabIndex = 4;
            this.btnLog.Text = "OK";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(27, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 17);
            this.label21.TabIndex = 3;
            this.label21.Text = "Iteration No.";
            // 
            // numLog
            // 
            this.numLog.Increment = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numLog.Location = new System.Drawing.Point(118, 29);
            this.numLog.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numLog.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLog.Name = "numLog";
            this.numLog.Size = new System.Drawing.Size(153, 22);
            this.numLog.TabIndex = 2;
            this.numLog.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numLog.ValueChanged += new System.EventHandler(this.numLog_ValueChanged);
            // 
            // rtbAll
            // 
            this.rtbAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbAll.Location = new System.Drawing.Point(30, 58);
            this.rtbAll.Margin = new System.Windows.Forms.Padding(4);
            this.rtbAll.Name = "rtbAll";
            this.rtbAll.ReadOnly = true;
            this.rtbAll.Size = new System.Drawing.Size(347, 594);
            this.rtbAll.TabIndex = 1;
            this.rtbAll.Text = "";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(13, 469);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(149, 21);
            this.checkBox1.TabIndex = 20;
            this.checkBox1.Text = "Use Random Seed";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Form_IBA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1762, 686);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbPicture);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "Form_IBA";
            this.Text = "Form_IBA";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIterations)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAtasPosisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBawahPosisi)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numScalingFactor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAlpha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_initpulse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Amin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ainit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_fmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_fmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPopulation)).EndInit();
            this.gbPicture.ResumeLayout(false);
            this.gbPicture.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartGrayLevel)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.originalImage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.processedImage)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLog)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbFunction;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtbBest;
        private System.Windows.Forms.TextBox textBest;
        private System.Windows.Forms.NumericUpDown numIterations;
        private System.Windows.Forms.ComboBox cbMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numAtasPosisi;
        private System.Windows.Forms.NumericUpDown numBawahPosisi;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numPopulation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown num_fmax;
        private System.Windows.Forms.NumericUpDown num_fmin;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown num_Amin;
        private System.Windows.Forms.NumericUpDown num_Ainit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown numBeta;
        private System.Windows.Forms.NumericUpDown numAlpha;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown num_initpulse;
        private System.Windows.Forms.GroupBox gbPicture;
        private System.Windows.Forms.PictureBox originalImage;
        private System.Windows.Forms.PictureBox processedImage;
        private System.Windows.Forms.Label lbOtsu;
        private System.Windows.Forms.Label lbOriginal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown numC;
        private System.Windows.Forms.NumericUpDown numF;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numScalingFactor;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGrayLevel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnLoadProcessedImage;
        private System.Windows.Forms.CheckBox checkBoxColor;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numLog;
        private System.Windows.Forms.RichTextBox rtbAll;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
    }
}