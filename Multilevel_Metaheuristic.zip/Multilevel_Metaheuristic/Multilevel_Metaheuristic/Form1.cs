﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multilevel_Metaheuristic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_FA_Click(object sender, EventArgs e)
        {
            Form FA = new Form_FA();
            FA.ShowDialog();
        }

        private void btn_SOS_Click(object sender, EventArgs e)
        {
            Form SOS = new Form_SOS();
            SOS.ShowDialog();
        }

        private void btn_IBA_Click(object sender, EventArgs e)
        {
            Form IBA = new Form_IBA();
            IBA.ShowDialog();
        }

        private void btn_Manual_Click(object sender, EventArgs e)
        {
            Form Manual = new Form_Manual();
            Manual.ShowDialog();
        }

        private void btn_Seed_Click(object sender, EventArgs e)
        {
            Form Seed = new Form_SEED();
            Seed.ShowDialog();
        }
    }
}
