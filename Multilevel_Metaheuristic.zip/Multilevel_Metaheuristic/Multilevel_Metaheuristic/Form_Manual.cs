﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Multilevel_Metaheuristic
{
    public partial class Form_Manual : Form
    {
        private int dimension = 0;
        //private int[] thresholds = new int[5];
        private int[] grayLevelCount = new int[256];//
        private int pixelCount = 0;//
        //private int multiLevel = 2;//
        private Boolean isImageLoaded = false;
        private Boolean isLocked = false;
        //private IBA_MULTI finalBat = null;
        private List<double> probabilityW = new List<double>(); //
        private List<Color> processedColor = new List<Color>();
        private List<double> thresholds = new List<double>();
        private String tracing = "";

        public Form_Manual()
        {
            InitializeComponent();
        }

        private void Form_Manual_Load(object sender, EventArgs e)
        {
            cbFunction.SelectedIndex = 1;
            dimension = cbFunction.SelectedIndex + 1;
            RefreshNum(dimension);

            chartGrayLevel.Series.Add("Gray Level");
            chartGrayLevel.Series["Gray Level"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Gray Level"].Color = Color.Gray;
            chartGrayLevel.Series.Add("Threshold");
            chartGrayLevel.Series["Threshold"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Threshold"].Color = Color.Chocolate;
            refreshGrayLevel();

            processedColor.Add(Color.Violet);
            processedColor.Add(Color.Blue);
            processedColor.Add(Color.Green);
            processedColor.Add(Color.Yellow);
            processedColor.Add(Color.Orange);
            processedColor.Add(Color.Red);
        }

        private void refreshGrayLevel()
        {
            for (int a = 0; a < 256; a++)
            {
                grayLevelCount[a] = 0;
            }
        }

        private void EnableAllNum()
        {
            num_1.Enabled = true;
            num_2.Enabled = true;
            num_3.Enabled = true;
            num_4.Enabled = true;
            num_5.Enabled = true;
        }

        private void DisableAllNum()
        {
            num_1.Enabled = false;
            num_2.Enabled = false;
            num_3.Enabled = false;
            num_4.Enabled = false;
            num_5.Enabled = false;
        }

        private void RefreshNum(int dim)
        {
            EnableAllNum();
            if (dim < 5)
            {
                num_5.Enabled = false;
                if (dim < 4)
                {
                    num_4.Enabled = false;
                    if (dim < 3)
                    {
                        num_3.Enabled = false;
                        if (dim < 2)
                        {
                            num_2.Enabled = false;
                            num_1.Enabled = false;
                        }
                    }
                }
            }
        }

        private void cbFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFunction.SelectedIndex == 0) cbFunction.SelectedIndex = 1;
            dimension = cbFunction.SelectedIndex + 1;
            RefreshNum(dimension);            
        }

        private void btnLoadProcessedImage_Click(object sender, EventArgs e)
        {
            if (isImageLoaded && isLocked)
            {
                label10.Text = "Score: " + Math.Round(fitnessmultiLevelD(thresholds.ToArray()), 4);
                Bitmap oImage = (Bitmap)originalImage.Image.Clone();
                Bitmap pImage = new Bitmap(originalImage.Width, originalImage.Height);

                List<double> totalThresh = new List<double>();
                List<double> countThresh = new List<double>();
                List<double> meanThresh = new List<double>();

                for (int dim = 0; dim <= dimension; dim++)
                {
                    meanThresh.Add(0);
                    countThresh.Add(0);
                    totalThresh.Add(0);
                }

                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        if (oImage.GetPixel(x, y).R < thresholds[0])
                        {
                            countThresh[0]++;
                            totalThresh[0] += oImage.GetPixel(x, y).R;
                        }
                        //rightmost
                        else if (oImage.GetPixel(x, y).R > thresholds[dimension - 1])
                        {
                            countThresh[dimension]++;
                            totalThresh[dimension] += oImage.GetPixel(x, y).R;
                        }
                        else
                        {
                            for (int dim = 0; dim < dimension-1; dim++)
                            {
                                //middle
                                if (oImage.GetPixel(x, y).R >= thresholds[dim] && oImage.GetPixel(x, y).R <= thresholds[dim + 1])
                                {
                                    countThresh[dim + 1]++;
                                    totalThresh[dim + 1] += oImage.GetPixel(x, y).R;
                                }
                            }
                        }
                    }
                }

                for (int dim = 0; dim <= dimension; dim++)
                {
                    if (countThresh[dim] == 0) countThresh[dim] = 1;
                    meanThresh[dim] = totalThresh[dim] / countThresh[dim];
                }

                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        int grayLevel = 0;
                        Color pixelColor = new Color();
                        for (int dim = 0; dim < dimension; dim++)
                        {
                            //leftmost
                            if (oImage.GetPixel(x, y).R < thresholds[0])
                            {
                                //grayLevel = Convert.ToInt32((minpos + thresholds[0]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[0]);
                                pixelColor = processedColor[0];
                                break;
                            }
                            //rightmost
                            else if (oImage.GetPixel(x, y).R > thresholds[dimension - 1])
                            {
                                //grayLevel = Convert.ToInt32((maxpos + thresholds[multiLevel - 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[dimension]);
                                pixelColor = processedColor[dimension];
                                break;
                            }
                            //middle
                            
                            else if (oImage.GetPixel(x, y).R >= thresholds[dim] && oImage.GetPixel(x, y).R <= thresholds[dim + 1])
                            {
                                //grayLevel = Convert.ToInt32((thresholds[dim] + thresholds[dim + 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[dim + 1]);
                                pixelColor = processedColor[dim + 1];
                                break;
                            }
                        }
                        if (checkBoxColor.Checked)
                        {
                            pImage.SetPixel(x, y, pixelColor);
                        }
                        else
                        {
                            pImage.SetPixel(x, y,
                            Color.FromArgb(grayLevel, grayLevel, grayLevel));
                        }
                    }
                }
                processedImage.Image = pImage;

                chartGrayLevel.Annotations.Clear();
                VerticalLineAnnotation[] VA = new VerticalLineAnnotation[10];
                for (int a = 0; a < dimension; a++)
                {
                    VA[a] = new VerticalLineAnnotation();
                    VA[a].AxisX = chartGrayLevel.ChartAreas[0].AxisX;
                    VA[a].AllowMoving = false;
                    VA[a].IsInfinitive = true;
                    VA[a].ClipToChartArea = chartGrayLevel.Name;
                    VA[a].Name = "T" + (a + 1);
                    VA[a].LineColor = Color.Chocolate;
                    VA[a].LineWidth = 1;
                    VA[a].X = thresholds[a];

                    chartGrayLevel.Annotations.Add(VA[a]);
                }
                chartGrayLevel.Update();
            }
            else
            {
                MessageBox.Show("Cannot");
            }
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            refreshGrayLevel();
            Image img;
            Bitmap bitImg;

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "PNG files (*.png)|*.png|GIF files (*.gif)|*.gif|JPEG files (*.jpg)|*.jpg|BITMAP files (*.bmp) |*.bmp";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                img = System.Drawing.Image.FromFile(dlg.FileName);
                gbPicture.Text = "Image : " + dlg.FileName;
                originalImage.Image = img;
                bitImg = (Bitmap)img.Clone();
                pixelCount = 0;
                for (int y = 0; y < bitImg.Height; y++)
                {
                    for (int x = 0; x < bitImg.Width; x++)
                    {
                        pixelCount++;
                        grayLevelCount[bitImg.GetPixel(x, y).R]++;
                    }
                }
                isImageLoaded = true;
                //btnStart.Enabled = isImageLoaded;

                int lowThresh = 0;
                int highThresh = 255;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        lowThresh = gLevel;
                        break;
                    }
                }
                for (int gLevel = 255; gLevel >= 0; gLevel--)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        highThresh = gLevel;
                        break;
                    }
                }

                foreach (var series in chartGrayLevel.Series)
                {
                    series.Points.Clear();
                }


                numBawahPosisi.Value = lowThresh;
                numAtasPosisi.Value = highThresh;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    chartGrayLevel.Series["Gray Level"].Points.AddXY(gLevel + 1, grayLevelCount[gLevel]);
                }

            }
            dlg.Dispose();

        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            isLocked = true;
            thresholds.Clear();
            thresholds.Add(Convert.ToDouble(num_1.Value));
            thresholds.Add(Convert.ToDouble(num_2.Value));
            thresholds.Add(Convert.ToDouble(num_3.Value));
            thresholds.Add(Convert.ToDouble(num_4.Value));
            thresholds.Add(Convert.ToDouble(num_5.Value));
            btn_clr.Enabled = true;
            btn_ok.Enabled = false;
            DisableAllNum();
        }

        private void btn_clr_Click(object sender, EventArgs e)
        {
            isLocked = false;
            btn_clr.Enabled = false;
            btn_ok.Enabled = true;
            RefreshNum(dimension);
        }

        private double fitnessmultiLevelD(double[] pstion)
        {
            tracing = "";
            probabilityW.Clear();
            double fitnessTotal = 0;
            //Find w0 - wk
            for (int dim = 0; dim <= dimension; dim++)
            {
                double WValue = 0;
                if (dim == 0)
                {
                    for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else if (dim == dimension)
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                probabilityW.Add(WValue);
            }
            //Find rightSideValue
            double rightSideValue = 0;
            for (int gLevel = 0; gLevel < 256; gLevel++)
            {
                rightSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
            }

            //Find totalFitness
            for (int dim = 0; dim <= dimension; dim++)
            {
                double leftSideValue = 0;

                if (probabilityW[dim] != 0)
                {
                    if (dim == 0)
                    {
                        for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else if (dim == dimension)
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                }
                double sigmaDim = probabilityW[dim] * (leftSideValue - rightSideValue) * (leftSideValue - rightSideValue);
                tracing += "variance-" + dim + " : " + sigmaDim + "\n";
                tracing += "probabilityW-" + dim + " : " + probabilityW[dim] + "\n";
                tracing += "leftmean-" + dim + " : " + leftSideValue + "\n";
                tracing += "rightsidemeanttl-" + dim + " : " + rightSideValue + "\n";
                tracing += "-----\n\n";
                fitnessTotal += sigmaDim;
            }
            richTextBox1.Text = tracing;
            return fitnessTotal;
            
        }
    }
}
