﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Multilevel_Metaheuristic
{
    public partial class Form_FA : Form
    {
        private int JenisFungsi = 0;
        private int JenisMode = 0;
        private double minpos = 0;
        private double maxpos = 0;
        private double alpha, beta, gamma = 0;
        private int iterasi = 1;
        private int populasi = 3;
        private Thread workerThread = null;
        private Boolean finished = false;

        //private double previousFitness = 0;
        private int[] grayLevelCount = new int[256];
        private int pixelCount = 0;
        private int multiLevel = 2;
        private Boolean isImageLoaded = false;
        private FA_MULTI finalFly = null;
        private List<double> probabilityW = new List<double>();
        private List<Color> processedColor = new List<Color>();
        private List<String> LogIsi = new List<string>();

        public Form_FA()
        {
            InitializeComponent();
            cbFunction.SelectedIndex = 1;
            cbMode.SelectedIndex = 1;

            chartGrayLevel.Series.Add("Gray Level");
            chartGrayLevel.Series["Gray Level"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Gray Level"].Color = Color.Gray;
            chartGrayLevel.Series.Add("Threshold");
            chartGrayLevel.Series["Threshold"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Threshold"].Color = Color.Chocolate;
            refreshGrayLevel();

            processedColor.Add(Color.Violet);
            processedColor.Add(Color.Blue);
            processedColor.Add(Color.Green);
            processedColor.Add(Color.Yellow);
            processedColor.Add(Color.Orange);
            processedColor.Add(Color.Red);
        }

        private void refreshGrayLevel()
        {
            for (int a = 0; a < 256; a++)
            {
                grayLevelCount[a] = 0;
            }
        }

        private void disableAll()
        {
            Boolean status = false;
            btnLoadImage.Enabled = status;
            btnStart.Enabled = status;
            numPopulation.Enabled = status;
            numIterations.Enabled = status;
            numAlpha.Enabled = status;
            numBeta.Enabled = status;
            numGamma.Enabled = status;
            cbFunction.Enabled = status;
            checkBox1.Enabled = status;
        }

        private void enableAll()
        {
            Boolean status = true;
            btnLoadImage.Enabled = status;
            btnStart.Enabled = status;
            numPopulation.Enabled = status;
            numIterations.Enabled = status;
            numAlpha.Enabled = status;
            numBeta.Enabled = status;
            numGamma.Enabled = status;
            cbFunction.Enabled = status;
            checkBox1.Enabled = status;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            finished = false;
            disableAll();
            JenisFungsi = cbFunction.SelectedIndex;
            JenisMode = cbMode.SelectedIndex;

            minpos = Convert.ToDouble(numBawahPosisi.Value);
            maxpos = Convert.ToDouble(numAtasPosisi.Value);

            alpha = Convert.ToDouble(numAlpha.Value);
            beta = Convert.ToDouble(numBeta.Value);
            gamma = Convert.ToDouble(numGamma.Value);

            iterasi = Convert.ToInt32(numIterations.Value);
            populasi = Convert.ToInt32(numPopulation.Value);

            if (JenisFungsi == 0)
            {
                workerThread = new Thread(new ThreadStart(Fungsi5D));
                workerThread.Start();
            }
            else
            {
                workerThread = new Thread(new ThreadStart(FungsiMulti));
                workerThread.Start();
            }
        }

        private void Fungsi5D()
        {
            finished = false;
            SetText(rtbAlpha, ""); SetText(textAlpha, "");
            FA_5D[] pop5 = new FA_5D[populasi];
            FA_5D bestFly = null;
            Random rng = new Random();

            for (int a = 0; a < populasi; a++)
            {
                //initialize
                double minip = rng.NextDouble() * (maxpos - minpos) + minpos;
                double maxip = rng.NextDouble() * (maxpos - minpos) + minpos;
                if (minip > maxip)
                {
                    minip = minip + maxip;
                    maxip = minip - maxip;
                    minip = minip - maxip;
                }
                pop5[a] = new FA_5D(minip, maxip);
            }

            DateTime start = new DateTime();
            DateTime stop = new DateTime();
            String elapsedTime = "";
            start = DateTime.Now;

            bestFly = pop5[0];
            for (int iter = 0; iter < iterasi; iter++)
            {
                for (int i = 0; i < populasi; i++)
                {
                    for (int j = 0; j < populasi; j++)
                    {
                        if (fitness5D(pop5[j].getPos()) < fitness5D(pop5[i].getPos()))
                        {
                            //menuju
                            double beta_pesona = beta * Math.Pow(Math.E, (-1 * gamma * diffpow(5, pop5[j].getPos(), pop5[i].getPos())));
                            pop5[i].changePos(pop5[j], beta_pesona, alpha);
                        }
                    }
                }
                String isiAll = "";
                for (int i = 0; i < populasi; i++)
                {
                    if (fitness5D(pop5[i].getPos()) < fitness5D(bestFly.getPos()))
                    {
                        bestFly = pop5[i];
                    }

                    isiAll += "No-" + (i + 1) + " : " + fitness5D(pop5[i].getPos()).ToString() + "\n";
                }

                stop = DateTime.Now;
                elapsedTime = (1000*(stop - start).Seconds + (stop - start).Milliseconds)+ "\n";

                String isiA = elapsedTime;
                //isiA += "Alpha : " + alpha + "\n";
                //String isiA = "";

                for (int dim = 0; dim < 5; dim++)
                {
                    isiA += "t" + (dim + 1) + " : " + bestFly.getPos()[dim] + "\n";
                }
                SetText(rtbAlpha, isiA);
                SetText(rtbAll, isiAll);
                SetText(textAlpha, fitness5D(bestFly.getPos()).ToString());
                SetText(btnRefresh, "Refresh(Now : " + (iter + 1) + ")");
                //if (alpha > 0.01) alpha *= 0.999;
                //numAlpha.Value = Convert.ToDecimal(alpha);
            }
            finished = true;
        }

        private void FungsiMulti()
        {
            finished = false;
            SetText(rtbAlpha, ""); SetText(textAlpha, "");
            LogIsi.Clear();
            FA_MULTI[] popmultiLevel = new FA_MULTI[populasi];
            FA_MULTI bestFly = new FA_MULTI(multiLevel, minpos, maxpos, maxpos, minpos, checkBox1.Checked, populasi);
            Random rng = new Random();

            for (int a = 0; a < populasi; a++)
            {                
                //initialize
                double minip = rng.NextDouble() * (maxpos - minpos) + minpos;
                double maxip = rng.NextDouble() * (maxpos - minpos) + minpos;
                if (minip > maxip)
                {
                    minip = minip + maxip;
                    maxip = minip - maxip;
                    minip = minip - maxip;
                }
                popmultiLevel[a] = new FA_MULTI(multiLevel, minip, maxip, maxpos, minpos, checkBox1.Checked, a);
            }

            bestFly.setPos(popmultiLevel[0].getPos());

            DateTime start = new DateTime();
            DateTime stop = new DateTime();
            String elapsedTime = "";
            String stopIter = "";
            start = DateTime.Now;
            double PreviousBest = 0;

            for (int iter = 0; iter < iterasi; iter++)
            {
                for (int i = 0; i < populasi; i++)
                {
                    for (int j = 0; j < populasi; j++)
                    {
                        if (fitnessmultiLevelD(popmultiLevel[j].getPos()) > fitnessmultiLevelD(popmultiLevel[i].getPos()))
                        {
                            //menuju
                            double beta_pesona = beta * Math.Pow(Math.E, (-1 * gamma * diffpow(multiLevel, popmultiLevel[j].getPos(), popmultiLevel[i].getPos())));
                            popmultiLevel[i].changePos(popmultiLevel[j], beta_pesona, alpha);
                        }
                    }
                }

                String isiAll = "";

                for (int i = 0; i < populasi; i++)
                {
                    if (fitnessmultiLevelD(popmultiLevel[i].getPos()) > fitnessmultiLevelD(bestFly.getPos()))
                    {
                        bestFly.setPos(popmultiLevel[i].getPos());
                    }

                    isiAll += "No-" + (i + 1) + " : " + Math.Round(fitnessmultiLevelD(popmultiLevel[i].getPos()), 2).ToString() + "";

                    for (int dim = 0; dim < multiLevel; dim++)
                    {
                        isiAll += "_" + Math.Round(popmultiLevel[i].getPos()[dim], 2);
                    }
                    isiAll += "\n";
                }

                if (PreviousBest != fitnessmultiLevelD(bestFly.getPos()))
                {
                    stop = DateTime.Now;
                    stopIter = (iter + 1) + "\n";
                }
                elapsedTime = (1000 * (stop - start).Seconds + (stop - start).Milliseconds) + "\n";
                String isiA = elapsedTime + stopIter;
                
                String isiBest = fitnessmultiLevelD(bestFly.getPos()).ToString()+"\n";

                //isiA += "Alpha : " + alpha + "\n";                

                for (int dim = 0; dim < multiLevel; dim++)
                {
                    isiA += "t" + (dim + 1) + " : " + Math.Round(bestFly.getPos()[dim], 2) + "\n";
                    isiBest+= "_" + Math.Ceiling(bestFly.getPos()[dim]);
                }

                SetText(rtbAlpha, isiA);
                SetText(textAlpha, fitnessmultiLevelD(bestFly.getPos()).ToString());
                LogIsi.Add("Best : " + isiBest + "\n\n" + isiAll);

                PreviousBest = Convert.ToDouble(fitnessmultiLevelD(bestFly.getPos()));
                SetText(btnRefresh, "Refresh(Now : " + (iter + 1) + ")");
            }
            finished = true;
            finalFly = bestFly;            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                btnRefresh.Text = "Refresh";
                enableAll();
                rtbAlpha.Clear(); textAlpha.Clear();
            }
            else
            {
                MessageBox.Show("Cannot!");
            }
        }

        private double fitness5D(double[] pstion)
        {
            double ttl = 0.0;
            for (int a = 0; a < 5; a++)
            {
                ttl += Math.Sin(pstion[a]) * Math.Pow(Math.Sin(a * pstion[a] * pstion[a] / Math.PI), 20);
            }
            double hsl = (-1.0 * ttl);
            //if (JenisMode == 0) return Math.Pow(hsl, -1);
            //else
            return hsl;
        }

        private double fitnessmultiLevelD(double[] pstion)
        {
            probabilityW.Clear();
            double fitnessTotal = 0;
            //Find w0 - wk
            for (int dim = 0; dim <= multiLevel; dim++)
            {
                double WValue = 0;
                if (dim == 0)
                {
                    for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else if (dim == multiLevel)
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                probabilityW.Add(WValue);
            }
            //Find rightSideValue
            double rightSideValue = 0;
            for (int gLevel = 0; gLevel < 256; gLevel++)
            {
                rightSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
            }

            //Find totalFitness
            for (int dim = 0; dim <= multiLevel; dim++)
            {
                double leftSideValue = 0;
                if (probabilityW[dim] != 0)
                {
                    if (dim == 0)
                    {
                        for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else if (dim == multiLevel)
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                }
                double sigmaDim = probabilityW[dim] * (leftSideValue - rightSideValue) * (leftSideValue - rightSideValue);
                fitnessTotal += sigmaDim;
            }
            return fitnessTotal;
        }

        private void cbFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFunction.SelectedIndex == 0)
            {
                numBawahPosisi.Value = 0;
                numAtasPosisi.Value = Convert.ToDecimal(Math.PI);
                cbMode.SelectedIndex = 0;
                btnStart.Enabled = true;

                this.Width = 975;
                gbPicture.Visible = false;
            }
            else
            {
                multiLevel = cbFunction.SelectedIndex + 1;
                cbMode.SelectedIndex = 1;
                btnStart.Enabled = isImageLoaded;
                numBawahPosisi.Enabled = true;
                numAtasPosisi.Enabled = true;

                lbOtsu.Text = "Otsu - m : " + multiLevel;
                this.Width = 1575;
                gbPicture.Visible = true;
            }
        }

        private double diffpow(int dimension, double[] i, double[] j)
        {
            double total = 0;
            for (int a = 0; a < dimension; a++)
            {
                total += Math.Pow((i[a] - j[a]), 2);
            }
            return total;
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            refreshGrayLevel();
            Image img;
            Bitmap bitImg;

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "PNG files (*.png)|*.png|GIF files (*.gif)|*.gif|JPEG files (*.jpg)|*.jpg|BITMAP files (*.bmp) |*.bmp";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                img = System.Drawing.Image.FromFile(dlg.FileName);
                gbPicture.Text = "Image : " + dlg.FileName;
                originalImage.Image = img;
                bitImg = (Bitmap)img.Clone();
                pixelCount = 0;
                for (int y = 0; y < bitImg.Height; y++)
                {
                    for (int x = 0; x < bitImg.Width; x++)
                    {
                        pixelCount++;
                        grayLevelCount[bitImg.GetPixel(x, y).R]++;
                    }
                }
                isImageLoaded = true;
                btnStart.Enabled = isImageLoaded;

                int lowThresh = 0;
                int highThresh = 255;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        lowThresh = gLevel;
                        break;
                    }
                }
                for (int gLevel = 255; gLevel >= 0; gLevel--)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        highThresh = gLevel;
                        break;
                    }
                }

                foreach (var series in chartGrayLevel.Series)
                {
                    series.Points.Clear();
                }


                numBawahPosisi.Value = lowThresh;
                numAtasPosisi.Value = highThresh;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    chartGrayLevel.Series["Gray Level"].Points.AddXY(gLevel + 1, grayLevelCount[gLevel]);
                }

            }
            dlg.Dispose();

        }

        private void btnLoadProcessedImage_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                Bitmap oImage = (Bitmap)originalImage.Image.Clone();
                Bitmap pImage = new Bitmap(originalImage.Width, originalImage.Height);

                List<double> totalThresh = new List<double>();
                List<double> countThresh = new List<double>();
                List<double> meanThresh = new List<double>();

                for (int dim = 0; dim <= multiLevel; dim++)
                {
                    meanThresh.Add(0);
                    countThresh.Add(0);
                    totalThresh.Add(0);
                }

                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        if (oImage.GetPixel(x, y).R < finalFly.getPos()[0])
                        {
                            countThresh[0]++;
                            totalThresh[0] += oImage.GetPixel(x, y).R;
                        }
                        //rightmost
                        else if (oImage.GetPixel(x, y).R > finalFly.getPos()[multiLevel - 1])
                        {
                            countThresh[multiLevel]++;
                            totalThresh[multiLevel] += oImage.GetPixel(x, y).R;
                        }
                        else
                        {
                            for (int dim = 0; dim < multiLevel; dim++)
                            {
                                //middle
                                if (oImage.GetPixel(x, y).R >= finalFly.getPos()[dim] && oImage.GetPixel(x, y).R <= finalFly.getPos()[dim + 1])
                                {
                                    countThresh[dim + 1]++;
                                    totalThresh[dim + 1] += oImage.GetPixel(x, y).R;
                                }
                            }
                        }
                    }
                }

                for (int dim = 0; dim <= multiLevel; dim++)
                {
                    if (countThresh[dim] == 0) countThresh[dim] = 1;
                    meanThresh[dim] = totalThresh[dim] / countThresh[dim];
                }

                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        int grayLevel = 0;
                        Color pixelColor = new Color();
                        for (int dim = 0; dim < multiLevel; dim++)
                        {
                            //leftmost
                            if (oImage.GetPixel(x, y).R < finalFly.getPos()[0])
                            {
                                //grayLevel = Convert.ToInt32((minpos + finalFly.getPos()[0]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[0]);
                                pixelColor = processedColor[0];
                                break;
                            }
                            //rightmost
                            else if (oImage.GetPixel(x, y).R > finalFly.getPos()[multiLevel - 1])
                            {
                                //grayLevel = Convert.ToInt32((maxpos + finalFly.getPos()[multiLevel - 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[multiLevel]);
                                pixelColor = processedColor[multiLevel];
                                break;
                            }
                            //middle
                            else if (oImage.GetPixel(x, y).R >= finalFly.getPos()[dim] && oImage.GetPixel(x, y).R <= finalFly.getPos()[dim + 1])
                            {
                                //grayLevel = Convert.ToInt32((finalFly.getPos()[dim] + finalFly.getPos()[dim + 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[dim + 1]);
                                pixelColor = processedColor[dim + 1];
                                break;
                            }
                        }
                        if (checkBoxColor.Checked)
                        {
                            pImage.SetPixel(x, y, pixelColor);
                        }
                        else
                        {
                            pImage.SetPixel(x, y,
                            Color.FromArgb(grayLevel, grayLevel, grayLevel));
                        }
                    }
                }
                processedImage.Image = pImage;

                chartGrayLevel.Annotations.Clear();
                VerticalLineAnnotation[] VA = new VerticalLineAnnotation[10];
                for (int a = 0; a < multiLevel; a++)
                {
                    VA[a] = new VerticalLineAnnotation();
                    VA[a].AxisX = chartGrayLevel.ChartAreas[0].AxisX;
                    VA[a].AllowMoving = false;
                    VA[a].IsInfinitive = true;
                    VA[a].ClipToChartArea = chartGrayLevel.Name;
                    VA[a].Name = "T" + (a + 1);
                    VA[a].LineColor = Color.Chocolate;
                    VA[a].LineWidth = 1;
                    VA[a].X = finalFly.getPos()[a];

                    chartGrayLevel.Annotations.Add(VA[a]);
                }
                chartGrayLevel.Update();
            }
            else
            {
                MessageBox.Show("Cannot!");
            }
        }        

        private void numLog_ValueChanged(object sender, EventArgs e)
        {
            if (numLog.Value >= numIterations.Value) numLog.Value = numIterations.Value;            
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                try
                {
                    SetText(rtbAll, "Iterasi : " + Convert.ToInt32(numLog.Value) + "\n\n" + LogIsi[Convert.ToInt32(numLog.Value) - 1]);
                }
                catch
                {
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textAlpha.Text + "\n" + rtbAlpha.Text);
        }

        private delegate void SetTextCallback(System.Windows.Forms.Control control, string text);

        private void SetText(System.Windows.Forms.Control control, string text)
        {
            if (control.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                Invoke(d, new object[] { control, text });
            }
            else
            {
                control.Text = text;
            }
        }
    }
}
