﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Metaheuristic
{
    class SOS_MULTI
    {
        private int level = new int();
        private List<double> posi = new List<double>();
        private double maxposs, minposs = new double();
        private double temp, fill = new double();
        private Random random = new Random();

        //normal
        public SOS_MULTI(int lv, double minpos, double maxpos)
        {
            level = lv;
            this.maxposs = maxpos;
            this.minposs = minpos;
            for (int a = 0; a < level; a++)
            {
                posi.Add(random.NextDouble() * (maxposs - minposs) + minposs);
            }
            posi.Sort();
        }

        //mv
        public SOS_MULTI(int lv, SOS_MULTI xi, SOS_MULTI xj)
        {
            posi.Clear(); level = lv;
            for (int a = 0; a < level; a++)
            {
                fill = (xi.getPos()[a] + xj.getPos()[a]) / 2;
                posi.Add(fill);
            }
            posi.Sort();
        }


        //mutualism
        public SOS_MULTI(int lv, SOS_MULTI x, double rnd, SOS_MULTI best, SOS_MULTI mv, int BF, double map, double mip)
        {
            posi.Clear(); level = lv;
            for (int a = 0; a < level; a++)
            {
                temp = x.getPos()[a];
                fill = x.getPos()[a] + rnd * (best.getPos()[a] - mv.getPos()[a] * Convert.ToDouble(BF));
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
            posi.Sort();
        }
        //comm
        public SOS_MULTI(int lv, SOS_MULTI x, double rnd, SOS_MULTI best, SOS_MULTI xj, double map, double mip)
        {
            posi.Clear(); level = lv;
            for (int a = 0; a < level; a++)
            {
                temp = x.getPos()[a];
                fill = x.getPos()[a] + rnd * (best.getPos()[a] - xj.getPos()[a]);
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
            posi.Sort();
        }
        //pv
        public SOS_MULTI(int lv, SOS_MULTI x, double map, double mip)
        {
            posi.Clear(); level = lv;
            for (int a = 0; a < level; a++)
            {
                temp = x.getPos()[a];
                if (random.Next(1, 3) == 1) fill = random.NextDouble() * (map - mip) + mip;
                else fill = x.getPos()[a] * (random.NextDouble() * (1.57));
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
            posi.Sort();
        }

        public double[] getPos()
        {
            return posi.ToArray();
        }

        public void setPos(double[] posit)
        {
            for (int a = 0; a < level; a++)
            {
                posi[a] = Convert.ToDouble(posit[a]);
            }
            posi.Sort();
        }
    }
}
