﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Metaheuristic
{
    class SOS_5D
    {
        private List<double> posi = new List<double>();
        private double maxposs, minposs = new double();
        private double temp, fill = new double();
        private Random random = new Random();

        //normal
        public SOS_5D(double minpos, double maxpos)
        {
            this.maxposs = maxpos;
            this.minposs = minpos;
            for (int a = 0; a < 5; a++)
            {
                posi.Add(random.NextDouble() * (maxposs - minposs) + minposs);
            }
        }

        //mv
        public SOS_5D(SOS_5D xi, SOS_5D xj)
        {
            posi.Clear();
            for (int a = 0; a < 5; a++)
            {
                fill = (xi.getPos()[a] + xj.getPos()[a]) / 2;
                posi.Add(fill);
            }             
        }


        //mutualism
        public SOS_5D(SOS_5D x, double rnd, SOS_5D best, SOS_5D mv, int BF, double map, double mip)
        {
            posi.Clear();
            for (int a = 0; a < 5; a++)
            {
                temp = x.getPos()[a];
                fill = x.getPos()[a] + rnd * (best.getPos()[a] - mv.getPos()[a] * Convert.ToDouble(BF));
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
             
        }
        //comm
        public SOS_5D(SOS_5D x, double rnd, SOS_5D best, SOS_5D xj, double map, double mip)
        {
            posi.Clear();
            for (int a = 0; a < 5; a++)
            {
                temp = x.getPos()[a];
                fill = x.getPos()[a] + rnd * (best.getPos()[a] - xj.getPos()[a]);
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
             
        }
        //pv
        public SOS_5D(SOS_5D x, double map, double mip)
        {
            posi.Clear();
            for (int a = 0; a < 5; a++)
            {
                temp = x.getPos()[a];
                if (random.Next(1, 3) == 1) fill = random.NextDouble() * (map - mip) + mip;
                else fill = x.getPos()[a] * (random.NextDouble() * (1.57));
                if (fill > map || fill < mip) fill = temp;
                posi.Add(fill);
            }
             
        }

        public double[] getPos()
        {
            return posi.ToArray();
        }

        public void setPos(double[] posit)
        {
            for (int a = 0; a < 5; a++)
            {
                posi[a] = Convert.ToDouble(posit[a]);
            }
             
        }
    }
}
