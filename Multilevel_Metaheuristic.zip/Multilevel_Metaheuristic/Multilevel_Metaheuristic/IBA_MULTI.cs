﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multilevel_Metaheuristic
{
    class IBA_MULTI
    {
        private int level = new int();
        private List<double> posi = new List<double>();
        private List<double> velocity_i = new List<double>();
        private double maxposs, minposs = new double();
        private double temp = new double();
        private Random random = new Random();

        public IBA_MULTI(int lv, double minpos, double maxpos)
        {
            level = lv;
            this.maxposs = maxpos;
            this.minposs = minpos;
            for (int a = 0; a < level; a++)
            {
                posi.Add(random.NextDouble() * (maxposs - minposs) + minposs);
                velocity_i.Add(0);
            }
            posi.Sort();
        }

        public double[] getPos()
        {
            return posi.ToArray();
        }
        
        public void setPos(double[] posit)
        {
            for (int a = 0; a < level; a++)
            {
                posi[a] = Convert.ToDouble(posit[a]);
            }
            posi.Sort();
        }

        public void changepos(IBA_MULTI bestbat, double f_i)
        {
            for (int a = 0; a < level; a++)
            {
                temp = posi[a];
                velocity_i[a] += (posi[a] - bestbat.getPos()[a]) * f_i;
                posi[a] += velocity_i[a];
                if (posi[a] > maxposs || posi[a] < minposs) posi[a] = temp;
            }
            posi.Sort();
        }

        public void changepos_dif(int dimension, double F, IBA_MULTI bat_a, IBA_MULTI bat_b, IBA_MULTI bat_c, double maxp, double minp)
        {
            temp = posi[dimension];
            posi[dimension] = bat_c.getPos()[dimension] + F * (bat_a.getPos()[dimension] - bat_b.getPos()[dimension]);
            if (posi[dimension] > maxp || posi[dimension] < minp) posi[dimension] = temp;
            posi.Sort();
        }

        public void changepos_loc(int dimension, IBA_MULTI modifierBat)
        {
            posi[dimension] = modifierBat.getPos()[dimension];
            posi.Sort();
        }

        public void setpos_modifierBat(double scalingFactor, double loudness, double maxp, double minp)
        {
            for (int a = 0; a < level; a++)
            {
                temp = posi[a];
                posi[a] += scalingFactor * loudness;
                if (posi[a] > maxp || posi[a] < minp) posi[a] = temp;
            }
            posi.Sort();
        }
    }
}
