﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multilevel_Metaheuristic
{
    public partial class Form_SEED : Form
    {
        private Random random = new Random();

        private double random_by_seed = new double();
        private double seed_xk = new double();
        private double seed_a = new double();
        private double seed_k = new double();
        private double seed_M = new double();

        public Form_SEED()
        {
            InitializeComponent();
            seed_a = 11;
            seed_k = 11;
            seed_M = 71;
            seed_xk = Convert.ToDouble(Math.Pow(Convert.ToInt32(seed_a), Convert.ToInt32(seed_k)) % Convert.ToInt32(seed_M));

        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            random = new Random();
            for (int a = 0; a < 10; a++)
            {
                richTextBox1.AppendText(random.NextDouble() + "\n");
            }
        }

        public void reRandom(double rseed_xk, double rseed_a, double rseed_M)
        {
            this.seed_xk = Convert.ToDouble((Convert.ToInt32(rseed_xk) * Convert.ToInt32(rseed_a)) % Convert.ToInt32(rseed_M));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("a: " + seed_a + "|k: " + seed_k + "|M: " + seed_M + "\n\n");
            for (int a = 0; a < 10; a++)
            {
                random_by_seed = seed_xk / seed_M;
                richTextBox1.AppendText(random_by_seed + "\n");
                reRandom(seed_xk, seed_a, seed_M);
            }
        }
    }
}
