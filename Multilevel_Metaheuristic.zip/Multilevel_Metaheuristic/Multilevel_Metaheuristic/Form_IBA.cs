﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Multilevel_Metaheuristic
{
    public partial class Form_IBA : Form
    {
        private int jenisFungsi = 0;
        private int jenisMode = 0;
        private double minpos, maxpos = 0;
        private double alpha, beta = 0;
        private double F, C = 0;
        private double Ainit, Amin = 0;
        private double fmin, fmax = 0;
        private double scalingFactor, initPulse = 0;
        private int iterasi = 1;
        private int populasi = 3;
        private Thread workerThread = null;
        private Boolean finished = false;

        private double previousFitness = 0;
        private int[] grayLevelCount = new int[256];//
        private int pixelCount = 0;//
        private int multiLevel = 2;   //
        private Boolean isImageLoaded = false;
        private IBA_MULTI finalBat = null;
        private List<double> probabilityW = new List<double>(); //
        private List<Color> processedColor = new List<Color>();
        private List<String> LogIsi = new List<string>();

        private double random_by_seed = new double();
        private double seed_xk = new double();
        private double seed_a = new double();
        private double seed_k = new double();
        private double seed_M = new double();

        public Form_IBA()
        {
            InitializeComponent();
            cbFunction.SelectedIndex = 1;
            cbMode.SelectedIndex = 1;

            chartGrayLevel.Series.Add("Gray Level");
            chartGrayLevel.Series["Gray Level"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Gray Level"].Color = Color.Gray;
            chartGrayLevel.Series.Add("Threshold");
            chartGrayLevel.Series["Threshold"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chartGrayLevel.Series["Threshold"].Color = Color.Chocolate;
            refreshGrayLevel();

            processedColor.Add(Color.Violet);
            processedColor.Add(Color.Blue);
            processedColor.Add(Color.Green);
            processedColor.Add(Color.Yellow);
            processedColor.Add(Color.Orange);
            processedColor.Add(Color.Red);
        }

        private void refreshGrayLevel()
        {
            for (int a = 0; a < 256; a++)
            {
                grayLevelCount[a] = 0;
            }
        }

        private void disableAll()
        {
            Boolean status = false;
            btnStart.Enabled = status;
            btnLoadImage.Enabled = status;
            numPopulation.Enabled = status;
            numIterations.Enabled = status;
            numAlpha.Enabled = status;
            numBeta.Enabled = status;
            num_initpulse.Enabled = status;
            num_fmin.Enabled = status;
            num_fmax.Enabled = status;
            num_Ainit.Enabled = status;
            num_Amin.Enabled = status;
            numF.Enabled = status;
            numC.Enabled = status;
            numAtasPosisi.Enabled = status;
            numBawahPosisi.Enabled = status;
            numScalingFactor.Enabled = status;
            cbFunction.Enabled = status;
            checkBox1.Enabled = status;
        }

        private void enableAll()
        {
            Boolean status = true;
            btnStart.Enabled = status;
            btnLoadImage.Enabled = status;
            numPopulation.Enabled = status;
            numIterations.Enabled = status;
            numAlpha.Enabled = status;
            numBeta.Enabled = status;
            num_initpulse.Enabled = status;
            num_fmin.Enabled = status;
            num_fmax.Enabled = status;
            num_Ainit.Enabled = status;
            num_Amin.Enabled = status;
            numF.Enabled = status;
            numC.Enabled = status;
            numAtasPosisi.Enabled = status;
            numBawahPosisi.Enabled = status;
            numScalingFactor.Enabled = status;
            cbFunction.Enabled = status;
            checkBox1.Enabled = status;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            finished = false;
            disableAll();
            jenisFungsi = cbFunction.SelectedIndex;
            jenisMode = cbMode.SelectedIndex;

            minpos = Convert.ToDouble(numBawahPosisi.Value);
            maxpos = Convert.ToDouble(numAtasPosisi.Value);

            fmin = Convert.ToDouble(num_fmin.Value);
            fmax = Convert.ToDouble(num_fmax.Value);

            Ainit = Convert.ToDouble(num_Ainit.Value);
            Amin = Convert.ToDouble(num_Amin.Value);

            initPulse = Convert.ToDouble(num_initpulse.Value);
            scalingFactor= Convert.ToDouble(numScalingFactor.Value);

            alpha = Convert.ToDouble(numAlpha.Value);
            beta = Convert.ToDouble(numBeta.Value);

            F = Convert.ToDouble(numF.Value);
            C = Convert.ToDouble(numC.Value);

            iterasi = Convert.ToInt32(numIterations.Value);
            populasi = Convert.ToInt32(numPopulation.Value);

            if (jenisFungsi == 0)
            {
                workerThread = new Thread(new ThreadStart(Fungsi5D));
                workerThread.Start();
            }
            else
            {
                workerThread = new Thread(new ThreadStart(FungsiMulti));
                workerThread.Start();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                finished = false;
                btnRefresh.Text = "Refresh";
                enableAll();
                rtbBest.Clear(); textBest.Clear();
            }
            else
            {
                MessageBox.Show("Cannot!");
            }
        }

        private void Fungsi5D()
        {
            finished = false;
            SetText(rtbBest, ""); SetText(textBest, "");
            IBA_5D[] pop5 = new IBA_5D[populasi];
            IBA_5D[] new_pop5 = new IBA_5D[populasi];

            IBA_5D bestBat = new IBA_5D(minpos, maxpos); //best
            IBA_5D modifierBat = new IBA_5D(minpos, maxpos); //lbest
            IBA_5D temp_pop5 = new IBA_5D(minpos, maxpos); //temp for new_pop5

            Random rng = new Random();

            double currentA_Loudness = new double();
            double currentPulse = new double();
            double f_i = new double();
            double randomDouble_1, randomDouble_2, randomDouble_3;
            int randomDimension, index_A, index_B, index_C;            

            //step 1 - generate
            for (int a = 0; a < populasi; a++)
            {
                //initialize
                double minip = rng.NextDouble() * (maxpos - minpos) + minpos;
                double maxip = rng.NextDouble() * (maxpos - minpos) + minpos;
                if (minip > maxip)
                {
                    minip = minip + maxip;
                    maxip = minip - maxip;
                    minip = minip - maxip;
                }
                pop5[a] = new IBA_5D(minip, maxip);
                new_pop5[a] = new IBA_5D(minip, maxip);
                new_pop5[a].setPos(pop5[a].getPos());                
                //find best
                if (a == 0)
                {
                    bestBat.setPos(pop5[a].getPos());
                }
                else if (fitness5D(pop5[a].getPos()) < fitness5D(bestBat.getPos()))
                {
                    bestBat.setPos(pop5[a].getPos());
                }                
            }

            //iteration
            for (int iter = 0; iter < iterasi; iter++)
            {
                //step 2 - calculate new population
                for (int a = 0; a < populasi; a++)
                {
                    //move bats
                    f_i = fmin + (fmax - fmin) * beta;
                    pop5[a].changepos(bestBat, f_i);
                }

                //random for step 3&4

                if (!checkBox1.Checked)
                {
                    randomDouble_1 = rng.NextDouble() * (1);
                    randomDouble_2 = rng.NextDouble() * (1);
                    randomDouble_3 = rng.NextDouble() * (1);
                }
                else
                {
                    randomDouble_1 = rng.NextDouble() * (1);
                    randomDouble_2 = rng.NextDouble() * (1);
                    randomDouble_3 = rng.NextDouble() * (1);
                }

                randomDimension = rng.Next(0, 5);

                modifierBat.setPos(bestBat.getPos());
                modifierBat.setpos_modifierBat(scalingFactor, currentA_Loudness, maxpos, minpos);

                //step 3 - improving
                currentPulse = initPulse * (1 - Math.Pow(Math.E, beta * (-1) * iter));
                for (int a = 0; a < populasi; a++)
                {
                    //mutation + crossover
                    if (randomDouble_1 > currentPulse)
                    {
                        for (int dim = 0; dim < 5; dim++)
                        {
                            if ((randomDouble_2 < C) || (dim == randomDimension))
                            {
                                //random bees index
                                index_A = rng.Next(0, populasi);
                                index_B = 0;
                                do
                                {
                                    index_B = rng.Next(0, populasi);
                                }
                                while (index_B == index_A);
                                index_C = 0;
                                do
                                {
                                    index_C = rng.Next(0, populasi);
                                }
                                while (index_C == index_A || index_C == index_B);
                                //change
                                new_pop5[a].changepos_dif(dim, F, pop5[index_A], pop5[index_B], pop5[index_C], maxpos, minpos);
                            }
                        }
                    }
                    //local search
                    else
                    {
                        for (int dim = 0; dim < 5; dim++)
                        {
                            temp_pop5.setPos(new_pop5[a].getPos());
                            temp_pop5.changepos_loc(dim, modifierBat);
                            //fungsi minimum
                            if (fitness5D(temp_pop5.getPos()) < fitness5D(new_pop5[a].getPos()))
                            {
                                new_pop5[a].setPos(temp_pop5.getPos());
                            }
                        }
                    }
                }

                //step 4 - acceptation
                if (iter == 0) currentA_Loudness = Ainit * alpha;
                else if (currentA_Loudness > Amin)
                {
                    currentA_Loudness = currentA_Loudness * alpha;
                }
                else
                {                    
                    currentA_Loudness = Amin;
                }
                for (int a = 0; a < populasi; a++)
                {
                    if ((randomDouble_3 < currentA_Loudness) && (fitness5D(new_pop5[a].getPos()) < fitness5D(pop5[a].getPos())))
                    {
                        pop5[a].setPos(new_pop5[a].getPos());
                    }
                }

                //step 5 - find best
                for (int a = 0; a < populasi; a++)
                {
                    //find best
                    if (a == 0)
                    {
                        bestBat.setPos(pop5[a].getPos());
                    }
                    else if (fitness5D(pop5[a].getPos()) < fitness5D(bestBat.getPos()))
                    {
                        bestBat.setPos(pop5[a].getPos());
                    }
                }

                String isiA = "";
                
                for (int dim = 0; dim < 5; dim++)
                {
                    isiA += "X ke-" + (dim + 1) + " : " + bestBat.getPos()[dim] + "\n";
                }
                SetText(rtbBest, isiA);
                SetText(textBest, fitness5D(bestBat.getPos()).ToString());

                SetText(btnRefresh, "Refresh(Now : " + (iter + 1) + ")");
            }
            finished = true;
        }

        private double fitness5D(double[] pstion)
        {
            double ttl = 0.0;
            for (int a = 0; a < 5; a++)
            {
                ttl += Math.Sin(pstion[a]) * Math.Pow(Math.Sin(a * pstion[a] * pstion[a] / Math.PI), 20);
            }
            double hsl = (-1.0 * ttl);
            //if (jenisMode == 0) return Math.Pow(hsl, -1);
            //else
            return hsl;
        }

        public void reRandom(double rseed_xk, double rseed_a, double rseed_M)
        {
            this.seed_xk = Convert.ToDouble((Convert.ToInt32(rseed_xk) * Convert.ToInt32(rseed_a)) % Convert.ToInt32(rseed_M));
        }

        private void FungsiMulti()
        {
            finished = false;
            SetText(rtbBest, ""); SetText(textBest, "");
            LogIsi.Clear();
            IBA_MULTI[] popmultiLevel = new IBA_MULTI[populasi];
            IBA_MULTI[] new_popmultiLevel = new IBA_MULTI[populasi];

            IBA_MULTI bestBat = new IBA_MULTI(multiLevel, minpos, maxpos); //best
            IBA_MULTI modifierBat = new IBA_MULTI(multiLevel, minpos, maxpos); //lbest
            IBA_MULTI temp_popmultiLevel = new IBA_MULTI(multiLevel, minpos, maxpos); //temp for new_popmultiLevel

            Random rng = new Random();
            seed_a = 11;
            seed_k = 2;
            seed_M = 7919;
            seed_xk = Convert.ToDouble(Math.Pow(Convert.ToInt32(seed_a), Convert.ToInt32(seed_k)) % Convert.ToInt32(seed_M));

            double currentA_Loudness = new double();
            double currentPulse = new double();
            double f_i = new double();
            double randomDouble_1, randomDouble_2, randomDouble_3;
            int randomDimension, index_A, index_B, index_C;

            //step 1 - generate
            for (int a = 0; a < populasi; a++)
            {
                //initialize
                double minip = rng.NextDouble() * (maxpos - minpos) + minpos;
                double maxip = rng.NextDouble() * (maxpos - minpos) + minpos;
                if (minip > maxip)
                {
                    minip = minip + maxip;
                    maxip = minip - maxip;
                    minip = minip - maxip;
                }
                popmultiLevel[a] = new IBA_MULTI(multiLevel, minip, maxip);
                new_popmultiLevel[a] = new IBA_MULTI(multiLevel, minip, maxip);
                new_popmultiLevel[a].setPos(popmultiLevel[a].getPos());
                //find best
                if (a == 0)
                {
                    bestBat.setPos(popmultiLevel[a].getPos());
                }
                else if (fitnessmultiLevelD(popmultiLevel[a].getPos()) > fitnessmultiLevelD(bestBat.getPos()))
                {
                    bestBat.setPos(popmultiLevel[a].getPos());
                }
            }

            DateTime start = new DateTime();
            DateTime stop = new DateTime();
            String elapsedTime = "";
            start = DateTime.Now;
            double PreviousBest = 0;
            String stopIter = "";

            //iteration
            for (int iter = 0; iter < iterasi; iter++)
            {
                previousFitness = fitnessmultiLevelD(bestBat.getPos());
                //step 2 - calculate new population
                for (int a = 0; a < populasi; a++)
                {
                    //move bats
                    f_i = fmin + (fmax - fmin) * beta;
                    popmultiLevel[a].changepos(bestBat, f_i);
                }

                //random for step 3&4
                if (!checkBox1.Checked)
                {
                    randomDouble_1 = rng.NextDouble() * (1);
                    randomDouble_2 = rng.NextDouble() * (1);
                    randomDouble_3 = rng.NextDouble() * (1);
                }
                else
                {
                    reRandom(seed_xk, seed_a, seed_M);
                    randomDouble_1 = seed_xk / seed_M * (1);
                    reRandom(seed_xk, seed_a, seed_M);
                    randomDouble_2 = seed_xk / seed_M * (1);
                    reRandom(seed_xk, seed_a, seed_M);
                    randomDouble_3 = seed_xk / seed_M * (1);
                }
                randomDimension = rng.Next(0, multiLevel);

                modifierBat.setPos(bestBat.getPos());
                modifierBat.setpos_modifierBat(scalingFactor, currentA_Loudness, maxpos, minpos);

                //step 3 - improving
                currentPulse = initPulse * (1 - Math.Pow(Math.E, beta * (-1) * iter));
                for (int a = 0; a < populasi; a++)
                {
                    //mutation + crossover
                    if (randomDouble_1 > currentPulse)
                    {
                        for (int dim = 0; dim < multiLevel; dim++)
                        {
                            if ((randomDouble_2 < C) || (dim == randomDimension))
                            {
                                //random bees index
                                index_A = rng.Next(0, populasi);
                                index_B = 0;
                                do
                                {
                                    index_B = rng.Next(0, populasi);
                                }
                                while (index_B == index_A);
                                index_C = 0;
                                do
                                {
                                    index_C = rng.Next(0, populasi);
                                }
                                while (index_C == index_A || index_C == index_B);
                                //change
                                new_popmultiLevel[a].changepos_dif(dim, F, popmultiLevel[index_A], popmultiLevel[index_B], popmultiLevel[index_C], maxpos, minpos);
                            }
                        }
                    }
                    //local search
                    else
                    {
                        for (int dim = 0; dim < multiLevel; dim++)
                        {
                            temp_popmultiLevel.setPos(new_popmultiLevel[a].getPos());
                            temp_popmultiLevel.changepos_loc(dim, modifierBat);
                            //fungsi maximum
                            if (fitnessmultiLevelD(temp_popmultiLevel.getPos()) > fitnessmultiLevelD(new_popmultiLevel[a].getPos()))
                            {
                                new_popmultiLevel[a].setPos(temp_popmultiLevel.getPos());
                            }
                        }
                    }
                }

                //step 4 - acceptation
                if (iter == 0) currentA_Loudness = Ainit * alpha;
                else if (currentA_Loudness > Amin)
                {
                    currentA_Loudness = currentA_Loudness * alpha;
                }
                else
                {
                    currentA_Loudness = Amin;
                }
                for (int a = 0; a < populasi; a++)
                {
                    if ((randomDouble_3 < currentA_Loudness) && (fitnessmultiLevelD(new_popmultiLevel[a].getPos()) > fitnessmultiLevelD(popmultiLevel[a].getPos())))
                    {
                        popmultiLevel[a].setPos(new_popmultiLevel[a].getPos());
                    }
                }

                //step multiLevel - find best
                for (int a = 0; a < populasi; a++)
                {
                    //find best
                    if (a == 0)
                    {
                        bestBat.setPos(popmultiLevel[a].getPos());
                    }
                    else if (fitnessmultiLevelD(popmultiLevel[a].getPos()) > fitnessmultiLevelD(bestBat.getPos()))
                    {
                        bestBat.setPos(popmultiLevel[a].getPos());
                    }
                }

                String isiAll = "";

                for (int i = 0; i < populasi; i++)
                {
                    if (fitnessmultiLevelD(popmultiLevel[i].getPos()) > fitnessmultiLevelD(bestBat.getPos()))
                    {
                        bestBat.setPos(popmultiLevel[i].getPos());
                    }

                    isiAll += "No-" + (i + 1) + " : " + Math.Round(fitnessmultiLevelD(popmultiLevel[i].getPos()), 2).ToString();

                    for (int dim = 0; dim < multiLevel; dim++)
                    {
                        isiAll += "_" + Math.Round(popmultiLevel[i].getPos()[dim], 2);
                    }
                    isiAll += "\n";
                }

                if (PreviousBest != fitnessmultiLevelD(bestBat.getPos()))
                {
                    stop = DateTime.Now;
                    stopIter = (iter+1) + "\n";
                }
                //if (previousFitness != fitnessmultiLevelD(bestBat.getPos()))
                elapsedTime = (1000*(stop - start).Seconds + (stop - start).Milliseconds) + "\n";

                String isiA = elapsedTime + stopIter;
                String isiBest = fitnessmultiLevelD(bestBat.getPos()).ToString()+"\n";

                for (int dim = 0; dim < multiLevel; dim++)
                {
                    isiA += "t" + (dim + 1) + " : " + Math.Round(bestBat.getPos()[dim], 2) + "\n";
                    isiBest += "_" + Math.Ceiling(bestBat.getPos()[dim]);
                }
                SetText(rtbBest, isiA);
                SetText(textBest, fitnessmultiLevelD(bestBat.getPos()).ToString());

                LogIsi.Add("Best : " + isiBest + "\n\n" + isiAll);

                PreviousBest = Convert.ToDouble(fitnessmultiLevelD(bestBat.getPos()));
                SetText(btnRefresh, "Refresh(Now : " + (iter + 1) + ")");                
            }
            finished = true;
            finalBat = bestBat;
        }

        private double fitnessmultiLevelD(double[] pstion)
        {
            probabilityW.Clear();
            double fitnessTotal = 0;
            //Find w0 - wk
            for (int dim = 0; dim <= multiLevel; dim++)
            {
                double WValue = 0;
                if (dim == 0)
                {
                    for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else if (dim == multiLevel)
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                else
                {
                    for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                    {
                        WValue += (Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
                    }
                }
                probabilityW.Add(WValue);
            }
            //Find rightSideValue
            double rightSideValue = 0;
            for (int gLevel = 0; gLevel < 256; gLevel++)
            {
                rightSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) / Convert.ToDouble(pixelCount));
            }

            //Find totalFitness
            for (int dim = 0; dim <= multiLevel; dim++)
            {
                double leftSideValue = 0;

                if (probabilityW[dim] != 0)
                {
                    if (dim == 0)
                    {
                        for (int gLevel = 0; gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else if (dim == multiLevel)
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < 256; gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                    else
                    {
                        for (int gLevel = Convert.ToInt32(pstion[dim - 1]); gLevel < Convert.ToInt32(pstion[dim]); gLevel++)
                        {
                            leftSideValue += (Convert.ToDouble(gLevel) * Convert.ToDouble(grayLevelCount[gLevel]) /
                                Convert.ToDouble(pixelCount) / Convert.ToDouble(probabilityW[dim]));
                        }
                    }
                }
                double sigmaDim = probabilityW[dim] * (leftSideValue - rightSideValue) * (leftSideValue - rightSideValue);
                fitnessTotal += sigmaDim;
            }
            return fitnessTotal;
        }
        
        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            refreshGrayLevel();
            Image img;
            Bitmap bitImg;

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "PNG files (*.png)|*.png|GIF files (*.gif)|*.gif|JPEG files (*.jpg)|*.jpg|BITMAP files (*.bmp) |*.bmp";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                img = System.Drawing.Image.FromFile(dlg.FileName);
                gbPicture.Text = "Image : " + dlg.FileName;
                originalImage.Image = img;
                bitImg = (Bitmap)img.Clone();
                pixelCount = 0;
                for (int y = 0; y < bitImg.Height; y++)
                {
                    for (int x = 0; x < bitImg.Width; x++)
                    {
                        pixelCount++;
                        grayLevelCount[bitImg.GetPixel(x, y).R]++;
                    }
                }
                isImageLoaded = true;
                btnStart.Enabled = isImageLoaded;

                int lowThresh = 0;
                int highThresh = 255;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        lowThresh = gLevel;
                        break;
                    }
                }
                for (int gLevel = 255; gLevel >= 0; gLevel--)
                {
                    if (grayLevelCount[gLevel] >= 10)
                    {
                        highThresh = gLevel;
                        break;
                    }
                }

                foreach (var series in chartGrayLevel.Series)
                {
                    series.Points.Clear();
                }
                

                numBawahPosisi.Value = lowThresh;
                numAtasPosisi.Value = highThresh;

                for (int gLevel = 0; gLevel < 256; gLevel++)
                {
                    chartGrayLevel.Series["Gray Level"].Points.AddXY(gLevel + 1, grayLevelCount[gLevel]);
                }

            }
            dlg.Dispose();

        }

        private void numLog_ValueChanged(object sender, EventArgs e)
        {
            if (numLog.Value >= numIterations.Value) numLog.Value = numIterations.Value;
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                try
                {
                    SetText(rtbAll, "Iterasi : " + Convert.ToInt32(numLog.Value) + "\n\n" + LogIsi[Convert.ToInt32(numLog.Value) - 1]);
                }
                catch
                {
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBest.Text + "\n" + rtbBest.Text);
        }

        private void btnLoadProcessedImage_Click(object sender, EventArgs e)
        {
            if (finished)
            {
                Bitmap oImage = (Bitmap)originalImage.Image.Clone();
                Bitmap pImage = new Bitmap(originalImage.Width, originalImage.Height);

                List<double> totalThresh = new List<double>();
                List<double> countThresh = new List<double>();
                List<double> meanThresh = new List<double>();

                for (int dim = 0; dim <= multiLevel; dim++)
                {
                    meanThresh.Add(0);
                    countThresh.Add(0);
                    totalThresh.Add(0);
                }

                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        if (oImage.GetPixel(x, y).R < finalBat.getPos()[0])
                        {
                            countThresh[0]++;
                            totalThresh[0] += oImage.GetPixel(x, y).R;
                        }
                        //rightmost
                        else if (oImage.GetPixel(x, y).R > finalBat.getPos()[multiLevel - 1])
                        {
                            countThresh[multiLevel]++;
                            totalThresh[multiLevel] += oImage.GetPixel(x, y).R;
                        }
                        else {
                            for (int dim = 0; dim < multiLevel; dim++)
                            {
                                //middle
                                if (oImage.GetPixel(x, y).R >= finalBat.getPos()[dim] && oImage.GetPixel(x, y).R <= finalBat.getPos()[dim + 1])
                                {
                                    countThresh[dim + 1]++;
                                    totalThresh[dim + 1] += oImage.GetPixel(x, y).R;
                                }
                            }
                        }
                    }
                }

                for (int dim = 0; dim <= multiLevel; dim++)
                {
                    if (countThresh[dim] == 0) countThresh[dim] = 1;
                    meanThresh[dim] = totalThresh[dim] / countThresh[dim];
                }
                
                for (int y = 0; y < originalImage.Height; y++)
                {
                    for (int x = 0; x < originalImage.Width; x++)
                    {
                        int grayLevel = 0;
                        Color pixelColor = new Color();
                        for (int dim = 0; dim < multiLevel; dim++)
                        {
                            //leftmost
                            if (oImage.GetPixel(x, y).R < finalBat.getPos()[0])
                            {
                                //grayLevel = Convert.ToInt32((minpos + finalBat.getPos()[0]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[0]);
                                pixelColor = processedColor[0];
                                break;
                            }
                            //rightmost
                            else if (oImage.GetPixel(x, y).R > finalBat.getPos()[multiLevel - 1])
                            {
                                //grayLevel = Convert.ToInt32((maxpos + finalBat.getPos()[multiLevel - 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[multiLevel]);
                                pixelColor = processedColor[multiLevel];
                                break;
                            }
                            //middle
                            else if (oImage.GetPixel(x, y).R >= finalBat.getPos()[dim] && oImage.GetPixel(x, y).R <= finalBat.getPos()[dim + 1])
                            {
                                //grayLevel = Convert.ToInt32((finalBat.getPos()[dim] + finalBat.getPos()[dim + 1]) / 2);
                                grayLevel = Convert.ToInt32(meanThresh[dim + 1]);
                                pixelColor = processedColor[dim + 1];
                                break;
                            }
                        }
                        if (checkBoxColor.Checked)
                        {
                            pImage.SetPixel(x, y, pixelColor);
                        }
                        else
                        {
                            pImage.SetPixel(x, y,
                            Color.FromArgb(grayLevel, grayLevel, grayLevel));
                        }
                    }
                }
                processedImage.Image = pImage;

                chartGrayLevel.Annotations.Clear();
                VerticalLineAnnotation[] VA = new VerticalLineAnnotation[10];
                for (int a = 0; a < multiLevel; a++)
                {
                    VA[a] = new VerticalLineAnnotation();
                    VA[a].AxisX = chartGrayLevel.ChartAreas[0].AxisX;
                    VA[a].AllowMoving = false;
                    VA[a].IsInfinitive = true;
                    VA[a].ClipToChartArea = chartGrayLevel.Name;                    
                    VA[a].Name = "T" + (a+1);
                    VA[a].LineColor = Color.Chocolate;
                    VA[a].LineWidth = 1;
                    VA[a].X = finalBat.getPos()[a];
                    
                    chartGrayLevel.Annotations.Add(VA[a]);                    
                }
                chartGrayLevel.Update();
            }
            else
            {
                MessageBox.Show("Cannot!");
            }
        }        

        private void num_Ainit_ValueChanged(object sender, EventArgs e)
        {
            if (num_Ainit.Value < num_Amin.Value) num_Ainit.Value = num_Amin.Value;
        }

        private void num_Amin_ValueChanged(object sender, EventArgs e)
        {
            if (num_Ainit.Value < num_Amin.Value) num_Amin.Value = num_Ainit.Value;
        }

        private void cbFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFunction.SelectedIndex == 0)
            {
                numBawahPosisi.Value = 0;
                numBawahPosisi.Enabled = false;
                numAtasPosisi.Value = Convert.ToDecimal(Math.PI);
                numAtasPosisi.Enabled = false;
                cbMode.SelectedIndex = 0;
                btnStart.Enabled = true;

                this.Width = 850+330;
                gbPicture.Visible = false;
            }
            else
            {
                multiLevel = cbFunction.SelectedIndex + 1;
                cbMode.SelectedIndex = 1;
                btnStart.Enabled = isImageLoaded;
                numScalingFactor.Value = Convert.ToDecimal(0.5);
                numBawahPosisi.Enabled = true;
                numAtasPosisi.Enabled = true;

                lbOtsu.Text = "Otsu - m : " + multiLevel;
                this.Width = 1450+330;
                gbPicture.Visible = true;
            }
        }

        private delegate void SetTextCallback(System.Windows.Forms.Control control, string text);

        private void SetText(System.Windows.Forms.Control control, string text)
        {
            if (control.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                Invoke(d, new object[] { control, text });
            }
            else
            {
                control.Text = text;
            }
        }        
    }
}
