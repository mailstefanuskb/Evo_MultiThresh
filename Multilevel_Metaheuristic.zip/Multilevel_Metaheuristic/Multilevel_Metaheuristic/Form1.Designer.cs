﻿namespace Multilevel_Metaheuristic
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_FA = new System.Windows.Forms.Button();
            this.btn_SOS = new System.Windows.Forms.Button();
            this.btn_IBA = new System.Windows.Forms.Button();
            this.btn_Manual = new System.Windows.Forms.Button();
            this.btn_Seed = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_FA
            // 
            this.btn_FA.Location = new System.Drawing.Point(12, 12);
            this.btn_FA.Name = "btn_FA";
            this.btn_FA.Size = new System.Drawing.Size(347, 84);
            this.btn_FA.TabIndex = 0;
            this.btn_FA.Text = "Firefly Algorithm";
            this.btn_FA.UseVisualStyleBackColor = true;
            this.btn_FA.Click += new System.EventHandler(this.btn_FA_Click);
            // 
            // btn_SOS
            // 
            this.btn_SOS.Location = new System.Drawing.Point(12, 102);
            this.btn_SOS.Name = "btn_SOS";
            this.btn_SOS.Size = new System.Drawing.Size(347, 84);
            this.btn_SOS.TabIndex = 1;
            this.btn_SOS.Text = "SOS";
            this.btn_SOS.UseVisualStyleBackColor = true;
            this.btn_SOS.Click += new System.EventHandler(this.btn_SOS_Click);
            // 
            // btn_IBA
            // 
            this.btn_IBA.Location = new System.Drawing.Point(12, 192);
            this.btn_IBA.Name = "btn_IBA";
            this.btn_IBA.Size = new System.Drawing.Size(347, 84);
            this.btn_IBA.TabIndex = 2;
            this.btn_IBA.Text = "Improved Bat Algorithm";
            this.btn_IBA.UseVisualStyleBackColor = true;
            this.btn_IBA.Click += new System.EventHandler(this.btn_IBA_Click);
            // 
            // btn_Manual
            // 
            this.btn_Manual.Location = new System.Drawing.Point(12, 333);
            this.btn_Manual.Name = "btn_Manual";
            this.btn_Manual.Size = new System.Drawing.Size(347, 84);
            this.btn_Manual.TabIndex = 3;
            this.btn_Manual.Text = "Manual";
            this.btn_Manual.UseVisualStyleBackColor = true;
            this.btn_Manual.Click += new System.EventHandler(this.btn_Manual_Click);
            // 
            // btn_Seed
            // 
            this.btn_Seed.Location = new System.Drawing.Point(12, 423);
            this.btn_Seed.Name = "btn_Seed";
            this.btn_Seed.Size = new System.Drawing.Size(347, 38);
            this.btn_Seed.TabIndex = 4;
            this.btn_Seed.Text = "Try RandomSeed";
            this.btn_Seed.UseVisualStyleBackColor = true;
            this.btn_Seed.Click += new System.EventHandler(this.btn_Seed_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 473);
            this.Controls.Add(this.btn_Seed);
            this.Controls.Add(this.btn_Manual);
            this.Controls.Add(this.btn_IBA);
            this.Controls.Add(this.btn_SOS);
            this.Controls.Add(this.btn_FA);
            this.Name = "Form1";
            this.Text = "Multilevel Image Thresholding";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_FA;
        private System.Windows.Forms.Button btn_SOS;
        private System.Windows.Forms.Button btn_IBA;
        private System.Windows.Forms.Button btn_Manual;
        private System.Windows.Forms.Button btn_Seed;
    }
}

